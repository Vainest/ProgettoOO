package Dao;


import java.util.ArrayList;

import ModelloUML.Traccia;


public interface TracciaDao {

	ArrayList<Traccia> RicavaTraccia(String query);
	
}
