package Dao;


import java.util.ArrayList;

import ModelloUML.*;

public interface UtenteDao {

//REGISTRAZIONE
	
	int RegistrazioneUtente(String NickName, String Password, String Nome, String Cognome,
			String DataDiNascita, String Sesso, String Nazionalita, boolean CheckAdmin);
		
//ACCESSO
	
	Utente AccessoUtente(String NickName, String Password);
	
//ELIMINARE IL SUO ACCOUNT
	
	int EliminaUtente(String query);
	
	//Ricerca Utente
	
	boolean CheckNickName(String NickName);
	
	//MODIFICA NICKNAME E PASSWORD
	
	int AggiornaDati(String NickName, String Password, String Nome, String Cognome, boolean CheckAdmin, String utente);
	
	
	ArrayList<Utente>RicavaUtenti(String query);


	
}
