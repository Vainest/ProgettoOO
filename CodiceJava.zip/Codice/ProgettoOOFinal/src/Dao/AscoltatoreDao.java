package Dao;
import java.util.ArrayList;


import ModelloUML.*;

public interface AscoltatoreDao {

	int InserisciAscoltatore(String query);
	
	ArrayList<Ascoltatore> RicavaAscoltatore(String query);
	
}
