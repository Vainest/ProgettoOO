package Dao;
import java.util.ArrayList;


import ModelloUML.Album;

public interface AlbumDao {
	

    ArrayList<Album> RicavaAlbum(String query);	
	
	
}
