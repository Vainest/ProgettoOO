package Dao;



import ModelloUML.BraniPreferiti;

public interface BraniPreferitiDao {

	
	int AggiornaBraniPreferiti(String query);
	
	BraniPreferiti RicavaBraniPreferiti(String query);	
	
	int AggiungiAiBraniPrefe(String query);
	
}
