package Dao;


import java.util.ArrayList;

import ModelloUML.Artista_T;

public interface Artista_TDao {


	Artista_T RicavaArtista(String query);
	
	ArrayList<Artista_T> RicavaArtisti(String query);
	
}
