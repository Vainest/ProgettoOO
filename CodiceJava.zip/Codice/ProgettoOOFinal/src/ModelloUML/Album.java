package ModelloUML;
import java.sql.Time;
import java.util.ArrayList;

public class Album {

	//DATI
	private int ID_Album;
	private String NomeAlbum;
	private Time DurataAlbum;
	private int AnnoUscita;
	private int N_Brani;
	
	private ArrayList<Traccia> TracceContenute;
	public Artista_T ArtistaAlbum;
	
	//COSTRUTTORE
	public Album(int ID_Album, String NomeAlbum, Time DurataAlbum, int AnnoUscita, int N_Brani,ArrayList<Traccia> TracceContenute
			, Artista_T ArtistaAlbum) {
		this.ID_Album = ID_Album;
		this.NomeAlbum = NomeAlbum;
		this.DurataAlbum = DurataAlbum;
		this.AnnoUscita = AnnoUscita;
		this.N_Brani = N_Brani;
		this.TracceContenute = TracceContenute;
		this.ArtistaAlbum = ArtistaAlbum;
	}



	//ASSOCIAZIONE TRACCIA
	public Album(Traccia t1) {
		TracceContenute.add(t1);
		t1.AlbumContenenteTracce = this;
	}
	
	
	//GETTERS AND SETTERS
	public String getNomeAlbum() {
		return NomeAlbum;
	}
	public void setNomeAlbum(String nomeAlbum) {
		NomeAlbum = nomeAlbum;
	}
	public Time getDurataAlbum() {
		return DurataAlbum;
	}
	public void setDurataAlbum(Time durataAlbum) {
		DurataAlbum = durataAlbum;
	}
	public int getAnnoUscita() {
		return AnnoUscita;
	}
	public void setAnnoUscita(int annoUscita) {
		AnnoUscita = annoUscita;
	}

	public int getID_Album() {
		return ID_Album;
	}

	public void setID_Album(int iD_Album) {
		ID_Album = iD_Album;
	}

	public int getN_Brani() {
		return N_Brani;
	}

	public void setN_Brani(int n_Brani) {
		N_Brani = n_Brani;
	}



	public ArrayList<Traccia> getTracceContenute() {
		return TracceContenute;
	}



	public void setTracceContenute(ArrayList<Traccia> tracceContenute) {
		TracceContenute = tracceContenute;
	}



	public Artista_T getArtistaAlbum() {
		return ArtistaAlbum;
	}



	public void setArtistaAlbum(Artista_T artistaAlbum) {
		ArtistaAlbum = artistaAlbum;
	}
	
	
}
