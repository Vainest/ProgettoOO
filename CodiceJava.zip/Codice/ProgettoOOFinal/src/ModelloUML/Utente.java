package ModelloUML;
import java.sql.Date;
import java.util.ArrayList;

public class Utente {

	//DATI
	
	protected String Password;
	protected String NickName;
	private String Nome;
	private String Cognome;
	private Date DataDiNascita;
    private String SessoUtente;
    private String Nazionalita;
    private boolean CheckAdmin;
   
    private ArrayList<Ascoltatore> RiproduzioneUtente; 
    
     private BraniPreferiti BraniPrefe;
    
    //COSTRUTTORE
    public Utente(String Password, String NickName, String Nome, String Cognome, Date DataDiNascita,
			String SessoUtente, String Nazionalita, boolean CheckAdmin,
			ArrayList<Ascoltatore> RiproduzioneUtente) {
		this.Password = Password;
		this.NickName = NickName;
		this.Nome = Nome;
		this.Cognome = Cognome;
		this.DataDiNascita = DataDiNascita;
		this.SessoUtente = SessoUtente;
		this.Nazionalita = Nazionalita;
		this.CheckAdmin = CheckAdmin;
		this.RiproduzioneUtente = RiproduzioneUtente;
	}
    
 
    public Utente(Ascoltatore a1) {
    	RiproduzioneUtente.add(a1);
    	a1.UtenteAscolto = this;
    }

    
    //ASSOCIAZIONE BRANI PREFERITI
	public Utente() {
    	BraniPrefe = new BraniPreferiti(this);
    }
	
	public BraniPreferiti getBraniPreferiti() {
		return BraniPrefe;
	}
	
	
    //GETTERS AND SETTERS
	public String getSessoUtente() {
		return SessoUtente;
	}
	public void setSessoUtente(String sessoUtente) {
		SessoUtente = sessoUtente;
	}
	
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getNickName() {
		return NickName;
	}
	public void setNickName(String nickName) {
		NickName = nickName;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getCognome() {
		return Cognome;
	}
	public void setCognome(String cognome) {
		Cognome = cognome;
	}
	public Date getDataDiNascita() {
		return DataDiNascita;
	}
	public void setDataDiNascita(Date dataDiNascita) {
		DataDiNascita = dataDiNascita;
	}
	public String getNazionalita() {
		return Nazionalita;
	}
	public void setNazionalita(String nazionalita) {
		Nazionalita = nazionalita;
	}


	public boolean CheckAdmin() {
		return CheckAdmin;
	}


	public void setCheckAdmin(boolean checkAdmin) {
		CheckAdmin = checkAdmin;
	}


	public ArrayList<Ascoltatore> getRiproduzioneUtente() {
		return RiproduzioneUtente;
	}


	public void setRiproduzioneUtente(ArrayList<Ascoltatore> riproduzioneUtente) {
		RiproduzioneUtente = riproduzioneUtente;
	}


	public BraniPreferiti getBraniPrefe() {
		return BraniPrefe;
	}


	public void setBraniPrefe(BraniPreferiti braniPrefe) {
		BraniPrefe = braniPrefe;
	}
	
	
	
	
	
	
	
}
