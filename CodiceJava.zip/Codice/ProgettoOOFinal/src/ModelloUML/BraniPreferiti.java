package ModelloUML;
import java.sql.Time;
import java.util.ArrayList;

public class BraniPreferiti {

	//DATI
	private int ID_BraniPreferiti;
	private int NumeroDiBrani;
	private Time TotaleMinutaggio;
	
	private Utente BraniPrefeUtente;
	
	private ArrayList<Traccia> TracceContenute;
	
	
	//COSTRUTTORE
	public BraniPreferiti(int ID_BraniPreferiti, int NumeroDiBrani, Time TotaleMinutaggio, 
			ArrayList<Traccia> TracceContenute) {
		this.ID_BraniPreferiti = ID_BraniPreferiti;
		this.NumeroDiBrani = NumeroDiBrani;
		this.TotaleMinutaggio = TotaleMinutaggio;
		this.TracceContenute = TracceContenute;
	}
	
	public BraniPreferiti() {
		
	}


	//ASSOCIAZIONE UTENTE
	public BraniPreferiti(Utente BraniPrefeUtente) {
		this.BraniPrefeUtente = BraniPrefeUtente;
	}
	
	public Utente getBraniPrefeUtente() {
		return BraniPrefeUtente;
	}


	//GETTERS AND SETTERS
	public int getNumeroDiBrani() {
		return NumeroDiBrani;
	}
	public void setNumeroDiBrani(int numeroDiBrani) {
		NumeroDiBrani = numeroDiBrani;
	}
	public Time getTempoTotale() {
		return TotaleMinutaggio;
	}
	public void setTempoTotale(Time tempoTotale) {
		TotaleMinutaggio = tempoTotale;
	}


	public int getID_BraniPreferiti() {
		return ID_BraniPreferiti;
	}


	public void setID_BraniPreferiti(int iD_BraniPreferiti) {
		ID_BraniPreferiti = iD_BraniPreferiti;
	}


	public ArrayList<Traccia> getTracceContenute() {
		return TracceContenute;
	}


	public void setTracceContenute(ArrayList<Traccia> tracceContenute) {
		TracceContenute = tracceContenute;
	}

	public Time getTotaleMinutaggio() {
		return TotaleMinutaggio;
	}

	public void setTotaleMinutaggio(Time totaleMinutaggio) {
		TotaleMinutaggio = totaleMinutaggio;
	}

	public void setBraniPrefeUtente(Utente braniPrefeUtente) {
		BraniPrefeUtente = braniPrefeUtente;
	}


	
	
	
}
