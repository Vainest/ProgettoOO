package ModelloUML;


public class Ascoltatore {

	
	private int FasciaOrariaAscolto;
	public Utente UtenteAscolto;
	public Traccia TracciaAscoltata;
	
	public Ascoltatore(int FasciaOrariaAscolto, Utente UtenteAscolto, Traccia TracciaAscoltata) {
		
		this.FasciaOrariaAscolto = FasciaOrariaAscolto;
		this.UtenteAscolto = UtenteAscolto;
		this.TracciaAscoltata = TracciaAscoltata;
		
	}

	public int getFasciaOrariaAscolto() {
		return FasciaOrariaAscolto;
	}

	public void setFasciaOrariaAscolto(int fasciaOrariaAscolto) {
		FasciaOrariaAscolto = fasciaOrariaAscolto;
	}

	public Utente getUtenteAscolto() {
		return UtenteAscolto;
	}

	public void setUtenteAscolto(Utente utenteAscolto) {
		UtenteAscolto = utenteAscolto;
	}

	public Traccia getTracciaAscoltata() {
		return TracciaAscoltata;
	}

	public void setTracciaAscoltata(Traccia tracciaAscoltata) {
		TracciaAscoltata = tracciaAscoltata;
	}
	
	
	
	
	
}
