package ModelloUML;
import java.sql.Date;
import java.util.ArrayList;

public class Artista_T {

	//DATI
	private int ID_ArtistaT;
	private String NomeArtista;
	private String Nazionalita;
	private String Sesso;
	private Date DataNascita;
	
	
	private ArrayList<Traccia> TracceProdotte;
	private ArrayList<Album> AlbumIncisi;
	
	//COSTRUTTORE
	public Artista_T(int ID_ArtistaT, String NomeArtista, String Nazionalita, String Sesso, Date DataNascita, 
			ArrayList<Traccia> TracceProdotte, ArrayList<Album> AlbumIncisi) {
		this.ID_ArtistaT = ID_ArtistaT;
		this.NomeArtista = NomeArtista;
		this.Nazionalita = Nazionalita;
		this.Sesso = Sesso;
		this.DataNascita = DataNascita;
		this.TracceProdotte = TracceProdotte;
		this.AlbumIncisi = AlbumIncisi;
	}
	
	public Artista_T() {
		
	}

	//ASSOCIAZIONE TRACCE E ALBUM
	public Artista_T(Traccia t1) {
		TracceProdotte.add(t1);
		t1.ArtistaTraccia = this;	
		
	}
	
	public Artista_T(Album a1) {
		AlbumIncisi.add(a1);
		a1.ArtistaAlbum = this;
	}
	
	
	//GETTERS AND SETTERS
	public String getNomeArtista() {
		return NomeArtista;
	}
	public void setNomeArtistaT(String nomeArtista) {
		NomeArtista = nomeArtista;
	}
	public String getNazionalita() {
		return Nazionalita;
	}
	public void setNazionalita(String nazionalita) {
		Nazionalita = nazionalita;
	}

	public String getSesso() {
		return Sesso;
	}
	public void setSesso(String sesso) {
		Sesso = sesso;
	}

	public int getID_ArtistaT() {
		return ID_ArtistaT;
	}

	public void setID_ArtistaT(int iD_ArtistaT) {
		ID_ArtistaT = iD_ArtistaT;
	}

	public Date getDataNascita() {
		return DataNascita;
	}

	public void setDataNascita(Date dataNascita) {
		DataNascita = dataNascita;
	}

	public ArrayList<Traccia> getTracceProdotte() {
		return TracceProdotte;
	}

	public void setTracceProdotte(ArrayList<Traccia> tracceProdotte) {
		TracceProdotte = tracceProdotte;
	}

	public ArrayList<Album> getAlbumIncisi() {
		return AlbumIncisi;
	}

	public void setAlbumIncisi(ArrayList<Album> albumIncisi) {
		AlbumIncisi = albumIncisi;
	}
	
	
}
