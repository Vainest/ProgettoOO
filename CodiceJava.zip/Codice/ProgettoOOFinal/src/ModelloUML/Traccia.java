package ModelloUML;
import java.sql.Time;
import java.util.ArrayList;

public class Traccia {

	//DATI
	private int ID_Traccia;
	private int N_TotaliAscolti;
	private String NomeTraccia;
	private int AnnoProduzione;
	private Time Durata;
	private String Genere;
	private boolean CheckCover;
	private boolean CheckRemastering;
	private int RifTracciaOriginale;
	
	private ArrayList<BraniPreferiti> PlaylistBraniPrefe;
	public Artista_T ArtistaTraccia;
	public Album AlbumContenenteTracce = null;
	private ArrayList<Ascoltatore> BraniRiprodotti;
	
	
	
    //COSTRUTTORE TRACCIA E REMASTERING
	public Traccia(int ID_Traccia, int N_TotaliAscolti, String NomeTraccia, int AnnoProduzione, Time Durata, String Genere,
			boolean CheckCover, boolean CheckRemastering, int RifTracciaOriginale, ArrayList<BraniPreferiti> PlaylistBraniPrefe, Artista_T ArtistaTraccia,
			ArrayList<Ascoltatore> BraniRiprodotti) {
		this.ID_Traccia = ID_Traccia;
		this.N_TotaliAscolti = N_TotaliAscolti;
		this.NomeTraccia = NomeTraccia;
		this.AnnoProduzione = AnnoProduzione;
		this.Durata = Durata;
		this.Genere = Genere;
		this.CheckRemastering = CheckRemastering;
		this.CheckCover = CheckCover;
		this.PlaylistBraniPrefe = PlaylistBraniPrefe;
		this.ArtistaTraccia = ArtistaTraccia;
		this.BraniRiprodotti = BraniRiprodotti;
	}

	//ASSOCIAZIONE ASCOLTATORE 1...*
	public Traccia(Ascoltatore a1) {
		BraniRiprodotti.add(a1);
		a1.TracciaAscoltata = this;
		
	}
	
	
	
	//GETTERS AND SETTERS
	
	public String getNome() {
		return NomeTraccia;
	}
	public void setNome(String nome) {
		NomeTraccia = nome;
	}
	
	public Time getDurata() {
		return Durata;
	}
	public void setDurata(Time durata) {
		Durata = durata;
	}
	public String getGenere() {
		return Genere;
	}
	public void setGenere(String genere) {
		Genere = genere;
	}


	public int getID_Traccia() {
		return ID_Traccia;
	}


	public void setID_Traccia(int iD_Traccia) {
		ID_Traccia = iD_Traccia;
	}


	public int getAnnoProduzione() {
		return AnnoProduzione;
	}


	public void setAnnoProduzione(int annoProduzione) {
		AnnoProduzione = annoProduzione;
	}


	public boolean CheckCover() {
		return CheckCover;
	}


	public void setCheckCover(boolean checkCover) {
		CheckCover = checkCover;
	}


	public boolean CheckRemastering() {
		return CheckRemastering;
	}


	public void setCheckRemastering(boolean checkRemastering) {
		CheckRemastering = checkRemastering;
	}


	public int getRifTracciaOriginale() {
		return RifTracciaOriginale;
	}


	public void setRifTracciaOriginale(int rifTracciaOriginale) {
		RifTracciaOriginale = rifTracciaOriginale;
	}

	public ArrayList<BraniPreferiti> getPlaylistBraniPrefe() {
		return PlaylistBraniPrefe;
	}

	public void setPlaylistBraniPrefe(ArrayList<BraniPreferiti> playlistBraniPrefe) {
		PlaylistBraniPrefe = playlistBraniPrefe;
	}

	public int getN_TotaliAscolti() {
		return N_TotaliAscolti;
	}

	public void setN_TotaliAscolti(int n_TotaliAscolti) {
		N_TotaliAscolti = n_TotaliAscolti;
	}

	public String getNomeTraccia() {
		return NomeTraccia;
	}

	public void setNomeTraccia(String nomeTraccia) {
		NomeTraccia = nomeTraccia;
	}

	public Artista_T getArtistaTraccia() {
		return ArtistaTraccia;
	}

	public void setArtistaTraccia(Artista_T artistaTraccia) {
		ArtistaTraccia = artistaTraccia;
	}

	public Album getAlbumContenenteTracce() {
		return AlbumContenenteTracce;
	}

	public void setAlbumContenenteTracce(Album albumContenenteTracce) {
		AlbumContenenteTracce = albumContenenteTracce;
	}

	public ArrayList<Ascoltatore> getBraniRiprodotti() {
		return BraniRiprodotti;
	}

	public void setBraniRiprodotti(ArrayList<Ascoltatore> braniRiprodotti) {
		BraniRiprodotti = braniRiprodotti;
	}
	
}
