package Controller;

import java.util.ArrayList;

import java.security.Timestamp;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;

import ImplementazioneDao.*;
import ModelloUML.*;

public class Controller {
	
	private Utente u;
	private UtenteImplDao uimp;
	private TracciaImplDao trimp;
	private AlbumImplDao alimp;
	private AscoltatoreImplDao asimp;
	private BraniPreferitiImplDao bpimp;
	private Artista_TImplDao artimp;
	
	public Controller() {
		uimp = new UtenteImplDao();
		trimp = new TracciaImplDao();
		alimp = new AlbumImplDao();
		asimp = new AscoltatoreImplDao();
		bpimp = new BraniPreferitiImplDao();
		artimp = new Artista_TImplDao();
	}
	
	public Utente AccessoUtente(String NickName, String password)
	{
		u = uimp.AccessoUtente(NickName, password);
		
		return u;
	}
	
	public int RegistrazioneUtente(String NickName, String Password, String Nome, String Cognome,
			String DataDiNascita, String Sesso, String Nazionalita, boolean CheckAdmin)
	{
		int esito;
		
		esito = uimp.RegistrazioneUtente(NickName, Password, Nome, Cognome,
				DataDiNascita, Sesso, Nazionalita,CheckAdmin);
		
		return esito;
	}
	
	
	public boolean CheckNickName(String nickName)
	{
		boolean esito = uimp.CheckNickName(nickName);
		
		return esito;
	}
	
	
	public int AggiornaDati(String NickName, String Password, String Nome, String Cognome, boolean CheckAdmin, String utente) {
		
		int esito=0;
		
		esito=uimp.AggiornaDati( NickName,Password,  Nome,  Cognome, CheckAdmin, utente);
		
		return esito;
	}
	
	
	public int EliminaUtente(String nickName)
	{
		int esito = uimp.EliminaUtente("delete from utente where nickname = '"+nickName+"';");
		
		return esito;
	}
	
	
	
	public ArrayList<Utente> RicavaUtenti(String query)
	{
		ArrayList<Utente> utenti =uimp.RicavaUtenti(query);
		
		return utenti;
	}
	


	
	public ArrayList<Traccia> RicavaTraccia(String query)
	{
		ArrayList<Traccia> tracce = null;
		
		tracce = trimp.RicavaTraccia(query);
		
		return tracce;
	}
	
	public ArrayList<Album> RicavaAlbum(String query)
	{
		ArrayList<Album> album = alimp.RicavaAlbum(query);
		
		return album;
	}
	
	
	public int InserisciAscoltatore(Traccia traccia, Utente utente) {
		
		int flag = 0;
		
		LocalTime time = LocalTime.now();
		
		int fascia = 0;
		
		if(time.getHour()>=0 && time.getHour()<=3) {
			
			fascia = 1;
			
		}else if(time.getHour()>=4 && time.getHour()<=7) {
			
			fascia = 2;
			
		}else if(time.getHour()>=8 && time.getHour()<=11) {
			
			fascia = 3;
			
		}else if(time.getHour()>=12 && time.getHour()<=15) {
			
			fascia = 4;
			
		}else if(time.getHour()>=16 && time.getHour()<=19) {
			
			fascia = 5;
			
		}else if(time.getHour()>=20 && time.getHour()<=23) {
			
			fascia = 6;
			
		}
		
		
		flag = asimp.InserisciAscoltatore("Insert into ascoltatore values ('"+utente.getNickName()+"', '"+traccia.getID_Traccia()+"', '"+fascia+"');");
		
		return flag;
		
		
	}
	

	
	public BraniPreferiti RicavaBraniPreferiti(String query)
	{
		BraniPreferiti branipreferiti = bpimp.RicavaBraniPreferiti(query);
		return branipreferiti;
	}
	
	public int AggiornaBraniPreferiti(String query)
	{
		int esito = bpimp.AggiornaBraniPreferiti(query);
		return esito;
	}
	
	
	public int AggiungiAiBraniPrefe(String query)
	{
		int esito = bpimp.AggiornaBraniPreferiti(query);
		return esito;
	}
	
	public Artista_T RicavaArtista(String query)
	{
		Artista_T artista = artimp.RicavaArtista(query);
		return artista;
	}
	
	public ArrayList<Artista_T> RicavaArtisti(String query)
	{
		ArrayList<Artista_T> artisti = artimp.RicavaArtisti(query);
		return artisti;
	}
	
	
	
	public ArrayList<Ascoltatore> RicavaAscoltatore(String query)
	{
		ArrayList<Ascoltatore> ascolti= asimp.RicavaAscoltatore(query);
		return ascolti;
	}
	

}