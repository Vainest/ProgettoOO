package ImplementazioneDao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;

import ConnessioneDatabase.ConnessioneDatabase;
import Dao.BraniPreferitiDao;
import ModelloUML.BraniPreferiti;
import ModelloUML.Traccia;


public class BraniPreferitiImplDao implements BraniPreferitiDao {
	
    private Connection connessione;
	
	public BraniPreferitiImplDao()
	{
	
		try {
			connessione = ConnessioneDatabase.getInstance().getConnection();
		}
		catch (SQLException e){
			e.printStackTrace();
		}
	}
	
	
	@Override
	public int AggiornaBraniPreferiti(String query) {
		
					int flag = 0;
		
		try{
			
			PreparedStatement queryAggiornaBraniPreferiti= connessione.prepareStatement(query);
			flag=queryAggiornaBraniPreferiti.executeUpdate();
			
		}catch(SQLException e){
			
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	
	public int AggiungiAiBraniPrefe(String query) {
		
		int flag = 0;

		try
		{
			PreparedStatement queryAggiornaBraniPreferiti= connessione.prepareStatement(query);
			flag=queryAggiornaBraniPreferiti.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

		return flag;
	}
	
	
		


	@Override
	public BraniPreferiti RicavaBraniPreferiti(String query) {
		
		BraniPreferiti branip=new BraniPreferiti();
		ArrayList <Traccia> tracce = new ArrayList<Traccia>();
		TracciaImplDao trimpl = new TracciaImplDao();
		
		int id_branipreferiti = 0;
		int n_brani;
		Time totaleminutaggio;
		BraniPreferiti bprefe = null;

		
		try {
		PreparedStatement queryRicavaPlaylist=connessione.prepareStatement(query);
		ResultSet rs=queryRicavaPlaylist.executeQuery();
		while(rs.next()) {
			id_branipreferiti = rs.getInt("Id_branipreferiti");
			n_brani = rs.getInt("numerobrani");
			totaleminutaggio = rs.getTime("Totaleminutaggio");
			

			
			tracce = trimpl.RicavaTraccia("SELECT * FROM TRACCIA as tr, contienetracce as ct WHERE tr.ID_TRACCIA = ct.ID_TRACCIA AND ct.ID_BRANIPREFERITI = '"+id_branipreferiti+"';");
			
			bprefe = new BraniPreferiti(id_branipreferiti, n_brani, totaleminutaggio, tracce);
			branip = bprefe;
			
	        }
		
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return branip;

}
	
}


