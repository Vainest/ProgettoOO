package ImplementazioneDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;

import ConnessioneDatabase.ConnessioneDatabase;
import Dao.TracciaDao;
import ModelloUML.Artista_T;
import ModelloUML.Traccia;

public class TracciaImplDao implements TracciaDao {
	
	private Connection connection;
	
	public TracciaImplDao()
	{
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		}
		catch (SQLException e){
			e.printStackTrace();
		}
	}

	@Override
	public ArrayList<Traccia> RicavaTraccia(String query) {
	
		ArrayList<Traccia> tracce = new ArrayList<Traccia>();
		Traccia tr = null;
		String nometraccia, genere, queryArtista;
		Time durata;
		int n_totaleascolti;
		int annoproduzione, id_traccia, riftracciaoriginale;
		boolean checkcover, checkremastering;	

		Artista_TImplDao ai = new Artista_TImplDao();
		Artista_T artista = new Artista_T();
		
		try {
			PreparedStatement queryTakeTraccia = connection.prepareStatement
			(query);
			ResultSet rs = queryTakeTraccia.executeQuery();
			
			while(rs.next())
			{
			
				nometraccia = rs.getString("NomeTraccia");
				genere = rs.getString("Genere");
				durata = rs.getTime("DurataTraccia");
				annoproduzione = rs.getInt("AnnoProduzione");
				n_totaleascolti = rs.getInt("N_TotaleAscolti");
				checkcover = rs.getBoolean("CheckCover");
				checkremastering = rs.getBoolean("CheckRemastering");
				id_traccia = rs.getInt("ID_Traccia");
				riftracciaoriginale = rs.getInt("RifTracciaOriginale");
										
				
				queryArtista = "SELECT * FROM ARTISTA_T, TRACCIA WHERE ARTISTA_T.ID_Artista = Traccia.id_artista AND Traccia.id_traccia = " +id_traccia;
				artista = ai.RicavaArtista(queryArtista);
				tr = new Traccia(id_traccia, n_totaleascolti ,nometraccia, annoproduzione, durata, genere, checkcover, checkremastering, riftracciaoriginale, null, artista, null);
				tracce.add(tr);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return tracce;
	}
		
	
		
}


