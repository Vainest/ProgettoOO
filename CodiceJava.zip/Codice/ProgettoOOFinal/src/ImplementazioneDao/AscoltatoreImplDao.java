package ImplementazioneDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ConnessioneDatabase.ConnessioneDatabase;
import Dao.AscoltatoreDao;
import ModelloUML.Ascoltatore;
import ModelloUML.Traccia;
import ModelloUML.Utente;

public class AscoltatoreImplDao implements AscoltatoreDao {
	
	private Connection connessione;
	private TracciaImplDao timp;
	private UtenteImplDao uimp;
	
	public AscoltatoreImplDao()
	{
		try {
			connessione = ConnessioneDatabase.getInstance().getConnection();
			timp = new TracciaImplDao();
			uimp = new UtenteImplDao();
			
		}
		catch (SQLException e){
			e.printStackTrace();
		}
	}
	

	@Override
	public int InserisciAscoltatore(String query) {
		
			int flag = 0;
		
		try{
			PreparedStatement queryInserisciAscoltatore = connessione.prepareStatement(query);
			flag = queryInserisciAscoltatore.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public ArrayList<Ascoltatore> RicavaAscoltatore(String query) {
		
		ArrayList<Ascoltatore> ascolti= new ArrayList<Ascoltatore>();
		ArrayList<Utente> utenti ;
		ArrayList<Traccia> tracce ; 
		Ascoltatore asc=null;
		
		String nickname;
		int id_traccia;
		int fasciaoraria;
		
		try{
			PreparedStatement queryAscoltatore = connessione.prepareStatement(query);
			ResultSet rs = queryAscoltatore.executeQuery();
			
			while(rs.next())
			{
				nickname=rs.getString("NickName");
				fasciaoraria=rs.getInt("FasciaOrariaAscolto");
				id_traccia=rs.getInt("ID_Traccia");
				utenti=uimp.RicavaUtenti("SELECT * FROM UTENTE WHERE NICKNAME='"+nickname+"' ;");
				tracce=timp.RicavaTraccia("SELECT * FROM TRACCIA WHERE id_traccia= '"+id_traccia+"';");
				asc= new Ascoltatore(fasciaoraria,utenti.get(0),tracce.get(0));
				ascolti.add(asc);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return ascolti ;
	}

}
