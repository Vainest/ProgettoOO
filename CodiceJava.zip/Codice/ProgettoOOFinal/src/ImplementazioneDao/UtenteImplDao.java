package ImplementazioneDao;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.ArrayList;

import Dao.UtenteDao;
import ModelloUML.Utente;
import ConnessioneDatabase.ConnessioneDatabase;

import java.sql.*;



public class UtenteImplDao implements UtenteDao {

	private Connection connection;
		
	public UtenteImplDao() {
		
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		}
		catch (SQLException e){
			e.printStackTrace();
		}
	}
	
	@Override
	public int RegistrazioneUtente(String NickName, String Password, String Nome, String Cognome,
			String DataDiNascita, String Sesso, String Nazionalita, boolean CheckAdmin) {
			int flag = 0;
		
		try{
			PreparedStatement queryRegistrazione = connection.prepareStatement("Insert INTO UTENTE "
					+ "Values('"+NickName+"','"+Nome+ "','" +Cognome+ "',"
							+ "'"+Sesso+ "','"+DataDiNascita+ "','" +Nazionalita+"',"
									+ "'" +Password+"','" +CheckAdmin+ "');");
			flag = queryRegistrazione.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return flag;
		
	}

	@Override
	public Utente AccessoUtente(String NickName, String Password) {
		
		Utente utente = null;
		
		String nickname, nome, cognome, nazionalita, password, sesso;
		Date datanascita;
		boolean checkAdmin;
		
		try {
			PreparedStatement queryAccesso = connection.prepareStatement
			("SELECT * FROM UTENTE WHERE NICKNAME = '" +NickName+"'");
			
			ResultSet rs = queryAccesso.executeQuery();
			
			if(rs == null)
			{
				System.out.println("Questo NickName non esiste");
			}
			while(rs.next())
			{
				
				nickname = rs.getString("NickName");
				nome = rs.getString("Nome");
				cognome = rs.getString("Cognome");
				nazionalita = rs.getString("Nazionalita");
				datanascita = rs.getDate("DataNascita");
				checkAdmin = rs.getBoolean("CheckAdmin");
				password = rs.getString("Password");
				sesso = rs.getString("SessoUtente");
	
				if(password.equals(Password))
				{
					utente = new Utente(password, nickname, nome, cognome, datanascita, sesso, nazionalita , checkAdmin, null);
				}
				else
				{
					System.out.println("Password non corretta");
				}
				
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return utente;
	}

	@Override
	public int EliminaUtente(String query) {
		int esito = 0;
		
		try
		{
			PreparedStatement queryEliminaUtente = connection.prepareStatement(query);
			esito = queryEliminaUtente.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return esito;
	}

	@Override
	public int AggiornaDati(String NickName, String Password, String Nome, String Cognome, boolean CheckAdmin, String utente) {
			int flag=0;
		
		try
		{
			PreparedStatement queryAggiornaDati= connection.prepareStatement("UPDATE UTENTE SET Nome = '"+Nome+"', Cognome = '"+Cognome+ "', NickName = '"+NickName+"' , Password = '"+Password+"' ,CheckAdmin = '"+CheckAdmin+"' WHERE NickName = '"+utente+"';");
			flag=queryAggiornaDati.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean CheckNickName(String NickName) {
		
		boolean flag = false;
		
		try{
			PreparedStatement queryCheckNick = connection.prepareStatement("SELECT * FROM UTENTE WHERE NickName= '"+NickName+"';");
			ResultSet rs1 = queryCheckNick.executeQuery();
			
			while(rs1.next())
			{
				flag = true;
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return flag;
	}

	
	@Override
	public ArrayList<Utente> RicavaUtenti(String query){
		
		ArrayList<Utente> utenti=new ArrayList<Utente>();
		Utente ut=null;
		String nickname, nome, cognome, nazionalita, password, sesso;
		Date datanascita;
		boolean checkAdmin;
		
		
		try
		{
			PreparedStatement queryRicavaUtenti= connection.prepareStatement(query);
			ResultSet rs=queryRicavaUtenti.executeQuery();
			while(rs.next()) {
				nickname=rs.getString("NickName");
				nome=rs.getString("Nome");
				cognome=rs.getString("Cognome");
				nazionalita=rs.getString("Nazionalita");
				password=rs.getString("Password");
				sesso=rs.getString("SessoUtente");
				datanascita=rs.getDate("DataNascita");
				checkAdmin=rs.getBoolean("CheckAdmin");
			
				ut=new Utente(password,nickname,nome,cognome,datanascita,sesso,nazionalita,checkAdmin, null);
				utenti.add(ut);	
				
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return utenti;
		
		
	}
	
	
	
}
