package ImplementazioneDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;

import ConnessioneDatabase.ConnessioneDatabase;
import Dao.AlbumDao;
import ModelloUML.Album;
import ModelloUML.Artista_T;
import ModelloUML.Traccia;
public class AlbumImplDao implements AlbumDao {

private Connection connessione;
	
	public AlbumImplDao()
	{
		try {
			connessione = ConnessioneDatabase.getInstance().getConnection();
		}
		catch (SQLException e){
			e.printStackTrace();
		}
	}
	
	
	@Override
	public ArrayList<Album> RicavaAlbum(String query) {

		ArrayList<Album> album= new ArrayList<Album>();
		Artista_T artista = new Artista_T();
		Artista_TImplDao artimpl = new Artista_TImplDao();
		TracciaImplDao trimpl = new TracciaImplDao();
		Album alb = null;
		ArrayList <Traccia> tracce = new ArrayList<Traccia>();
		
		String nomeAlbum, queryArtista;
		int annouscita, n_tracce, id_album;
		Time durata;
		
		try {
			PreparedStatement queryRicavaAlbum = connessione.prepareStatement(query);
			
			ResultSet rs = queryRicavaAlbum.executeQuery();
			
			while(rs.next())
			{
				id_album = rs.getInt("ID_Album");
				nomeAlbum = rs.getString("NomeAlbum");
				durata = rs.getTime("DurataTotale");
				annouscita = rs.getInt("AnnoUscita");
				n_tracce = rs.getInt("N_Brani");
				
				queryArtista = "SELECT * FROM ARTISTA_T, ALBUM WHERE ARTISTA_T.ID_ARTISTA = ALBUM.ID_ARTISTA AND ALBUM.ID_ALBUM = " + id_album;
				artista = artimpl.RicavaArtista(queryArtista);
				
				
					tracce = trimpl.RicavaTraccia("Select * from traccia, formatotraccia where traccia.id_traccia = formatotraccia.id_traccia "
							+ "and formatotraccia.id_album =" + id_album);
				
				alb = new Album(id_album, nomeAlbum, durata, annouscita, n_tracce, tracce, artista);
				album.add(alb);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return album;

	}
}
