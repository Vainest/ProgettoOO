package ImplementazioneDao;

import java.util.ArrayList;


import Dao.Artista_TDao;
import ModelloUML.Artista_T;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ConnessioneDatabase.ConnessioneDatabase;
import ModelloUML.Album;
import ModelloUML.Artista_T;

public class Artista_TImplDao implements Artista_TDao {

	private Connection connessione;
	
	public Artista_TImplDao()
	{
		try {
			connessione = ConnessioneDatabase.getInstance().getConnection();
		}
		catch (SQLException e){
			e.printStackTrace();
		}
	}
	
	
	@Override
	public Artista_T RicavaArtista(String query) {
		
		Artista_T Artista_T = null;
		String NomeArtista;
		String Nazionalita;
		Date DataNascita;
		int ID_ArtistaT;
		String Sesso;
		
		Artista_T artistatmp;
		
		try {
			PreparedStatement queryRicavaArtista = connessione.prepareStatement
			(query);
			
			ResultSet rs = queryRicavaArtista.executeQuery();
			
			while(rs.next())
			{
				ID_ArtistaT = rs.getInt(1);
				NomeArtista = rs.getString(2);
				Nazionalita = rs.getString(3);
				Sesso = rs.getString(4);
				DataNascita = rs.getDate(5);
				
				artistatmp = new Artista_T(ID_ArtistaT, NomeArtista, Nazionalita, Sesso, DataNascita, null, null);
				Artista_T = artistatmp;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return Artista_T;
		
	}
	
	@Override
	public ArrayList<Artista_T> RicavaArtisti(String query) {
		
		ArrayList<Artista_T> artisti = new ArrayList<>();
		Artista_T art;
		String NomeArtista;
		String Nazionalita;
		Date DataNascita;
		int ID_ArtistaT;
		String Sesso;
		
		
		try {
			PreparedStatement queryRicavaArtista = connessione.prepareStatement
			(query);
			
			ResultSet rs = queryRicavaArtista.executeQuery();
			
			while(rs.next())
			{
				ID_ArtistaT = rs.getInt("ID_Artista");
				NomeArtista = rs.getString("NomeArtista");
				Nazionalita = rs.getString("Nazionalita");
				Sesso = rs.getString("SessoArtista");
				DataNascita = rs.getDate("DataNascita");
				
				art = new Artista_T(ID_ArtistaT, NomeArtista, Nazionalita, Sesso, DataNascita, null, null);
				artisti.add(art);
				
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return artisti;
		
	}
	
	
	}


