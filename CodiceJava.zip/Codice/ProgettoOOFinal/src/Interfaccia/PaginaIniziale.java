package Interfaccia;

		import java.awt.BorderLayout;

		import java.awt.Dimension;
		import java.awt.EventQueue;
		import java.awt.Toolkit;

		import javax.swing.JFrame;
		import javax.swing.JPanel;
		import javax.swing.border.EmptyBorder;
import javax.swing.colorchooser.ColorChooserComponentFactory;

import Controller.Controller;
		import ModelloUML.*;
		import javax.swing.JComboBox;
		import javax.swing.JList;
		import javax.swing.JOptionPane;
		import javax.swing.JLabel;
		import java.awt.Font;
		import javax.swing.ImageIcon;
		import java.awt.Color;
		import javax.swing.JScrollBar;
		import java.awt.Choice;
		import javax.swing.SwingConstants;
		import java.awt.TextField;
		import java.awt.event.KeyAdapter;
		import java.awt.event.KeyEvent;
		import java.util.ArrayList;

		import javax.swing.GroupLayout;
		import javax.swing.GroupLayout.Alignment;
		import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextPane;
import javax.swing.DropMode;

public class PaginaIniziale extends JFrame{

			private JPanel contentPane;
			private JFrame paginainiziale;
			private ArrayList<Traccia> tracce;
			private Album album;
			private ArrayList<Utente> utenti;
			private ArrayList<BraniPreferiti> branipreferiti;
			private ArrayList<Artista_T> artisti;
			private JFrame pagprecedente;
			private String cerca;
			private BraniPreferiti braniprefe;
			private DettagliBraniPrefe dettaglibraniprefe;
			private PannelloGenerale pannelloGenerale;


			/**
			 * Create the frame.
			 */
			public PaginaIniziale(JFrame login, Utente utente, Controller controller) {
				setResizable(false);
				
			    paginainiziale = new JFrame();
				login.setVisible(false);
				paginainiziale = this;
				paginainiziale.setVisible(true);
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setBounds(100, 100, 1090, 660);
				contentPane = new JPanel();
				contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
				setContentPane(contentPane);
				contentPane.setLayout(null);
				paginainiziale.setTitle("Pagina iniziale");
				
					Toolkit toolkit = getToolkit();
				Dimension size = toolkit.getScreenSize();
				setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
				
				JComboBox SelezionaBox = new JComboBox();
				SelezionaBox.setBounds(593, 24, 84, 22);
				SelezionaBox.addItem("Album");
				SelezionaBox.addItem("Traccia");
				SelezionaBox.addItem("Artista");
				SelezionaBox.addItem("Utente");
				
				TextField CercaField = new TextField();
				CercaField.setBounds(394, 23, 190, 25);
				
				CercaField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {
						
						if(e.getKeyCode() == KeyEvent.VK_ENTER) {
							
							int x = SelezionaBox.getSelectedIndex();
							
							switch(x){
							
							
						case 0: 
							

							cerca = CercaField.getText();
							 pannelloGenerale = new PannelloGenerale(paginainiziale, controller, PaginaIniziale.this, utente ,cerca, 0);
							CercaField.setText("");
									break;
								
							case 1:
								
								cerca = CercaField.getText();
								pannelloGenerale = new PannelloGenerale(paginainiziale, controller, PaginaIniziale.this, utente ,cerca, 1);
								CercaField.setText("");
								break;
								
								
							case 2:
								cerca = CercaField.getText();
								pannelloGenerale = new PannelloGenerale(paginainiziale, controller, PaginaIniziale.this, utente ,cerca, 2);
								CercaField.setText("");
								break;
								
								
								
							case 3:
								
								cerca = CercaField.getText();
								ArrayList<Utente> controllaUtente;
								controllaUtente = controller.RicavaUtenti("select * from utente where nickname = '"+cerca+"';");
								
								if(cerca.equals("") || controllaUtente.size()>0) {
									
								DettagliUtente dettagliutente = new DettagliUtente(paginainiziale, utente, controller, PaginaIniziale.this, cerca);
								CercaField.setText("");
									
								}else {
								
								JOptionPane.showMessageDialog(paginainiziale, "Non esiste un utente che inizia con questo nickname");
								CercaField.setText("");
								
								}
								
								break;
							
				
							
							}
							
							
						}
						
					}
				});
				
				

				
				JLabel BraniPreferitiLB = new JLabel("");
				BraniPreferitiLB.setIcon(new ImageIcon(PaginaIniziale.class.getResource("/Immagini/PaginaIniziale/braniprefe.png")));
				BraniPreferitiLB.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						
					 dettaglibraniprefe =	new DettagliBraniPrefe(paginainiziale, utente ,controller, PaginaIniziale.this, true);
					
					}
				});
				
				
				BraniPreferitiLB.setBounds(0, 125, 214, 39);
				BraniPreferitiLB.setForeground(Color.WHITE);
				BraniPreferitiLB.setFont(new Font("Tahoma", Font.PLAIN, 23));
				
				JLabel CercaLB = new JLabel("Cerca...");
				CercaLB.setBounds(296, 15, 95, 39);
				CercaLB.setForeground(Color.WHITE);
				CercaLB.setFont(new Font("Tahoma", Font.PLAIN, 23));
				
				JLabel LogOutLB = new JLabel("");
				LogOutLB.setIcon(new ImageIcon(PaginaIniziale.class.getResource("/Immagini/PaginaIniziale/logout.png")));
				LogOutLB.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						
						login.setVisible(true);
						System.out.println("Sei uscito dalla libreria musicale");
						dispose();
						
						
						
					}
				});
				LogOutLB.setBounds(0, 581, 110, 40);
				LogOutLB.setFont(new Font("Tahoma", Font.PLAIN, 27));
				LogOutLB.setForeground(Color.WHITE);
				
				
				
				
				
				
				
				
				
				JLabel ImpostazioniLB = new JLabel("");
				ImpostazioniLB.setIcon(new ImageIcon(PaginaIniziale.class.getResource("/Immagini/PaginaIniziale/impostazioni.png")));
				ImpostazioniLB.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						Impostazioni impostazioni = new Impostazioni(paginainiziale,login,controller, utente);
						dispose();
						
					}
				});
				ImpostazioniLB.setBounds(0, 176, 186, 39);
				ImpostazioniLB.setForeground(Color.WHITE);
				ImpostazioniLB.setFont(new Font("Tahoma", Font.PLAIN, 23));
				
				JLabel SfondoNero = new JLabel("");
				SfondoNero.setBounds(0, 0, 214, 621);
				SfondoNero.setIcon(new ImageIcon(PaginaIniziale.class.getResource("/Immagini/PaginaIniziale/BarraSinistra.png")));
				
				JLabel HomeLB = new JLabel("");
				HomeLB.setIcon(new ImageIcon(PaginaIniziale.class.getResource("/Immagini/PaginaIniziale/home.png")));
				HomeLB.setBounds(0, 74, 127, 39);
				HomeLB.setFont(new Font("Tahoma", Font.PLAIN, 23));
				HomeLB.setForeground(Color.WHITE);
				
				JLabel TitoloLB = new JLabel("");
				TitoloLB.setIcon(new ImageIcon(PaginaIniziale.class.getResource("/Immagini/PaginaIniziale/titolo.png")));
				TitoloLB.setBounds(0, 0, 186, 50);
				TitoloLB.setForeground(Color.WHITE);
				TitoloLB.setFont(new Font("Tahoma", Font.PLAIN, 28));
				contentPane.setLayout(null);
				

			
				
				contentPane.add(SelezionaBox);
				contentPane.add(ImpostazioniLB);
				contentPane.add(BraniPreferitiLB);
				contentPane.add(HomeLB);
				contentPane.add(TitoloLB);
				contentPane.add(LogOutLB);
				contentPane.add(SfondoNero);
				contentPane.add(CercaLB);
				contentPane.add(CercaField);
						
						JTextPane txtpnSelezionareUnaDelle = new JTextPane();
						txtpnSelezionareUnaDelle.setFont(new Font("Times New Roman", Font.BOLD, 18));
						txtpnSelezionareUnaDelle.setText("Selezionare una delle seguenti scelte a fianco alla barra di ricerca.\r\nSe si vuole visualizzare una lista delle varie scelte, non digitare nulla e premere invio.");
						txtpnSelezionareUnaDelle.setBounds(340, 74, 474, 90);
						contentPane.add(txtpnSelezionareUnaDelle);
							
						ArrayList<Traccia> riscanzoneasc;
						riscanzoneasc = controller.RicavaTraccia("SELECT t.nometraccia, count(*) as numeroascolti, t.genere, t.duratatraccia, t.annoproduzione, t.N_TotaleAscolti, t.CheckCover, t.CheckRemastering, t.ID_Traccia, t.RifTracciaOriginale \r\n"
								+ "FROM ASCOLTATORE AS a, TRACCIA AS t\r\n"
								+ "WHERE a.id_traccia=t.id_traccia and \r\n"
								+ "a.nickname='"+utente.getNickName()+"'\r\n"
								+ "group by (a.nickname, t.nometraccia,t.genere, t.duratatraccia, t.annoproduzione, t.N_TotaleAscolti,  t.CheckCover, t.CheckRemastering, t.ID_Traccia, t.RifTracciaOriginale)\r\n"
								+ "order by numeroascolti desc limit 1");
						
					if(riscanzoneasc.size()!=0) {
						
							JLabel RisCanzoneAsc = new JLabel("La canzone che ami di piu': "+riscanzoneasc.get(0).getNomeTraccia());
							RisCanzoneAsc.setFont(new Font("Times New Roman", Font.BOLD, 25));
							RisCanzoneAsc.setForeground(Color.WHITE);
							RisCanzoneAsc.setBounds(251, 258, 603, 100);
							contentPane.add(RisCanzoneAsc);
	
					}
					
					ArrayList<Traccia> riscanzonedb;
					
					riscanzonedb = controller.RicavaTraccia("SELECT t.nometraccia, count(*) as numeroascolti,  t.genere, t.duratatraccia, t.annoproduzione, t.N_TotaleAscolti, t.CheckCover, t.CheckRemastering, t.ID_Traccia, t.RifTracciaOriginale \r\n"
							+ "FROM ASCOLTATORE AS a, TRACCIA AS t\r\n"
							+ "WHERE a.id_traccia=t.id_traccia\r\n"
							+ "group by (a.nickname, t.nometraccia,t.genere, t.duratatraccia, t.annoproduzione, t.N_TotaleAscolti,  t.CheckCover, t.CheckRemastering, t.ID_Traccia, t.RifTracciaOriginale)\r\n"
							+ "order by numeroascolti desc limit 1");
					
					if(riscanzoneasc.size()!=0) {
					
									JLabel lblLaCanzonePiu = new JLabel("La canzone piu' ascoltata nella libreria: "+riscanzonedb.get(0).getNomeTraccia());
									lblLaCanzonePiu.setForeground(Color.WHITE);
									lblLaCanzonePiu.setFont(new Font("Times New Roman", Font.BOLD, 25));
									lblLaCanzonePiu.setBounds(251, 400, 603, 100);
									contentPane.add(lblLaCanzonePiu);
									
					}					
											
											
													
													JLabel Sfondo = new JLabel("");
													Sfondo.setBounds(191, 0, 883, 621);
													Sfondo.setIcon(new ImageIcon(PaginaIniziale.class.getResource("/Immagini/PaginaIniziale/back.jpg")));
													contentPane.add(Sfondo);
				
				
				
			}
	}



