package Interfaccia;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Controller.Controller;
import ModelloUML.BraniPreferiti;
import ModelloUML.Traccia;
import ModelloUML.Utente;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;



public class DettagliBraniPrefe extends JFrame{

	private JPanel contentPane;
	private JFrame dettaglibraniprefe = new JFrame();
	private JList<Traccia> listaTracce = new JList<>();
	private DefaultListModel demoList = new DefaultListModel();
	private ArrayList<Traccia> ListaTracce;
	private BraniPreferiti BraniPrefe;
	private JLabel TitoloLB = new JLabel("");
	private JLabel NomeLB = new JLabel("");
	private JLabel RisTotMinutaggioLB = new JLabel("Totale minutaggio");
	private JLabel RisNumBraniLB = new JLabel("Numero di brani");
	private JScrollPane scrollPane = new JScrollPane();
	private JLabel TempoTotaleLB = new JLabel("");
	private JLabel lblNumeroDiBrani = new JLabel("");
	private JLabel IndietroLB = new JLabel("");
	private JLabel PaginaInizialeLB = new JLabel("");
	private JLabel DettagliTracciaLB = new JLabel("");
	private JLabel AscoltaLB = new JLabel("");
	private JLabel Sfondo = new JLabel("");
	
	
	public DettagliBraniPrefe(JFrame paginainiziale, Utente utente ,Controller controller, JFrame indietro, boolean flag) {

		
		paginainiziale.setVisible(false);
		dettaglibraniprefe=this;
		dettaglibraniprefe.setVisible(true);
		System.out.println("Ti trovi in dettagli brani preferiti");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dettaglibraniprefe.setTitle("Dettagli brani preferiti");
		
		setBounds(100, 100, 933, 602);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		FinestraAlCentro();
		
		//INIZIALIZZAZIONE DELLA LISTA DI BRANI PREFERITI
		InizializzaBraniP(controller,utente);	
		
		
		TitoloLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/BraniPrefeDi.png")));
		TitoloLB.setForeground(Color.WHITE);
		TitoloLB.setFont(new Font("Tahoma", Font.PLAIN, 32));
		TitoloLB.setBounds(163, 11, 309, 73);
		contentPane.add(TitoloLB);
		
		NomeLB.setForeground(Color.WHITE);
		NomeLB.setFont(new Font("Tahoma", Font.PLAIN, 25));
		NomeLB.setBounds(418, 18, 193, 52);
		contentPane.add(NomeLB);
		NomeLB.setText(""+utente.getNickName()+"");
		
		RisTotMinutaggioLB.setForeground(Color.WHITE);
		RisTotMinutaggioLB.setHorizontalAlignment(SwingConstants.LEFT);
		RisTotMinutaggioLB.setFont(new Font("Tahoma", Font.PLAIN, 18));
		RisTotMinutaggioLB.setBounds(722, 101, 148, 73);
		contentPane.add(RisTotMinutaggioLB);
		RisTotMinutaggioLB.setText(""+BraniPrefe.getTotaleMinutaggio()+"");
		
		RisNumBraniLB.setForeground(Color.WHITE);
		RisNumBraniLB.setHorizontalAlignment(SwingConstants.LEFT);
		RisNumBraniLB.setFont(new Font("Tahoma", Font.PLAIN, 18));
		RisNumBraniLB.setBounds(723, 190, 148, 73);
		contentPane.add(RisNumBraniLB);
		RisNumBraniLB.setText(""+BraniPrefe.getNumeroDiBrani()+"");
		
		//Inizializza la lista di tracce, nome-artista.
		InizializzaList(controller,utente);
		
		scrollPane.setBounds(23, 112, 656, 348);
		contentPane.add(scrollPane);
		scrollPane.setViewportView(listaTracce);
		listaTracce.setFont(new Font("Times New Roman", Font.BOLD, 24));
		
		TempoTotaleLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/TempoTotaleLB.png")));
		TempoTotaleLB.setForeground(Color.WHITE);
		TempoTotaleLB.setFont(new Font("Tahoma", Font.PLAIN, 16));
		TempoTotaleLB.setBounds(705, 79, 147, 20);
		contentPane.add(TempoTotaleLB);
		
		lblNumeroDiBrani.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/NumeroDiBraniLB.png")));
		lblNumeroDiBrani.setForeground(Color.WHITE);
		lblNumeroDiBrani.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNumeroDiBrani.setBounds(705, 178, 149, 16);
		contentPane.add(lblNumeroDiBrani);
		
		//L'utente può modificare solo la sua lista di brani preferiti
		if(flag) {
			JLabel EliminaLB = new JLabel("");
			EliminaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/eliminabtngreen.png")));
			EliminaLB.setBounds(737, 481, 118, 71);
			contentPane.add(EliminaLB);
			EliminaLB.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					
					if(listaTracce.getSelectedIndex() != -1) {	
					
					controller.AggiornaBraniPreferiti("delete from contienetracce as tr where tr.id_traccia = '"+ListaTracce.get(listaTracce.getSelectedIndex()).getID_Traccia()+"' and tr.id_branipreferiti = '"+BraniPrefe.getID_BraniPreferiti()+"';");
					DettagliBraniPrefe dettaglibranipre = new DettagliBraniPrefe(paginainiziale,  utente , controller, indietro, flag);
					dispose();
				
					
					}else {
						
						JOptionPane.showMessageDialog(contentPane, "Non hai selezionato la traccia", "Attento!", JOptionPane.WARNING_MESSAGE);
					}
					
					
					}
					
					
				@Override
				public void mouseEntered(MouseEvent e) {
					EliminaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/eliminabtnwhite.png")));
				}
				@Override
				public void mouseExited(MouseEvent e) {
					EliminaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/eliminabtngreen.png")));
				}
			});
		
	}
		
		
		IndietroLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Indietrobtngreen.png")));
		IndietroLB.setBounds(10, 498, 110, 54);
		contentPane.add(IndietroLB);
		InterazioneBTNIndietro(IndietroLB,indietro);
		
		
		PaginaInizialeLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/paginainizialebtngreen.png")));
		PaginaInizialeLB.setBounds(124, 498, 167, 54);
		PaginaInizialeLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				paginainiziale.setVisible(true);
				System.out.println("Ti trovi nella pagina iniziale");
				dispose();
			
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				PaginaInizialeLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/paginizialebtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				PaginaInizialeLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/paginainizialebtngreen.png")));
			}
		});
		contentPane.add(PaginaInizialeLB);
		
		DettagliTracciaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Dettaglitrbtngreen.png")));
		DettagliTracciaLB.setBounds(705, 268, 183, 82);
		contentPane.add(DettagliTracciaLB);
		DettagliTracciaLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(listaTracce.getSelectedIndex() != -1) {	
				
			Traccia nome;
			nome = ListaTracce.get(listaTracce.getSelectedIndex());
				
			DettagliTraccia dettaglitraccia = new DettagliTraccia(paginainiziale, controller, DettagliBraniPrefe.this, utente, nome);
			dispose();
			
				}else {
					
					JOptionPane.showMessageDialog(contentPane, "Non hai selezionato la traccia", "Attento!", JOptionPane.WARNING_MESSAGE);
					
				}
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				DettagliTracciaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Dettaglitrbtnwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				DettagliTracciaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Dettaglitrbtngreen.png")));
			}
		});
		
		
		
		AscoltaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Ascoltabtngreen.png")));
		AscoltaLB.setBounds(741, 371, 110, 82);
		contentPane.add(AscoltaLB);
		InterazioneBTNAscolta(AscoltaLB,controller,utente, dettaglibraniprefe);
		
		
		Sfondo.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Sfondo.jpg")));
		Sfondo.setBounds(0, 0, 917, 563);
		contentPane.add(Sfondo);
			
		
		
	}
	
private void InizializzaList(Controller controller, Utente utente) {
	
		ListaTracce = controller.RicavaTraccia("select * from traccia as tr, utente as ut, contienetracce as ct, branipreferiti as bp "
				+ "where tr.id_traccia = ct.id_traccia and bp.nickname = ut.nickname and "
				+ "ct.id_branipreferiti = bp.id_branipreferiti and ut.nickname = '"+utente.getNickName()+"';");
	
		int i;
		
		for(i=0; i<ListaTracce.size(); i++){
			demoList.addElement("Traccia: "+ListaTracce.get(i).getNomeTraccia()+" - Artista: "+ListaTracce.get(i).getArtistaTraccia().getNomeArtista());
		}
		listaTracce.setModel(demoList);
	}

private void InizializzaBraniP(Controller controller, Utente utente) {
	
	BraniPrefe = controller.RicavaBraniPreferiti("select * from branipreferiti as bp, utente as ut where ut.nickname = bp.nickname and bp.nickname = '"+utente.getNickName()+"';");
	
	
	}



//SETTA LA FINESTRA APERTA AL CENTRO DELLO SCHERMO
private void FinestraAlCentro() {
	
	Toolkit toolkit = dettaglibraniprefe.getToolkit();
	Dimension size = toolkit.getScreenSize();
	dettaglibraniprefe.setLocation(size.width/2 - dettaglibraniprefe.getWidth()/2, size.height/2 - dettaglibraniprefe.getHeight()/2);
	
}

private void InterazioneBTNIndietro(JLabel IndietroLB, JFrame indietro) {
	IndietroLB.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
		
			indietro.setVisible(true);
			dispose();
			
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			
			IndietroLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Indietrobtnwhite.png")));
			
		}
		@Override
		public void mouseExited(MouseEvent e) {
			
			IndietroLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Indietrobtngreen.png")));
			
		}
	});
	
	
}


private void InterazioneBTNAscolta(JLabel AscoltaLB, Controller controller, Utente utente, JFrame DettagliBraniPrefe) {
	
	AscoltaLB.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
			
			if(listaTracce.getSelectedIndex() != -1) {	
			
			//ASCOLTO CANZONE
			int flag = controller.InserisciAscoltatore(ListaTracce.get(listaTracce.getSelectedIndex()), utente);
			
			if(flag == 1) {
				JOptionPane.showMessageDialog(DettagliBraniPrefe, "Brano ascoltato!");
				System.out.println("Brano ascoltato con successo");
				
			}else {
				JOptionPane.showMessageDialog(DettagliBraniPrefe, "Brano non ascoltato!");
				System.out.println("Riproduzione non andata a buon fine");
				
			}
			
			}else {
				
				JOptionPane.showMessageDialog(contentPane, "Non hai selezionato la traccia", "Attento!", JOptionPane.WARNING_MESSAGE);
				
			}
			
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			
			AscoltaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Ascoltabtnwhite.png")));
			
			
		}
		@Override
		public void mouseExited(MouseEvent e) {
			
			AscoltaLB.setIcon(new ImageIcon(DettagliBraniPrefe.class.getResource("/Immagini/DettagliBraniPrefe/Ascoltabtngreen.png")));
			
		}
	});
	
}





}
