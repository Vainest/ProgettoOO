package Interfaccia;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Controller.Controller;
import ModelloUML.Ascoltatore;
import ModelloUML.Traccia;
import ModelloUML.Utente;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

public class PannelloAdmin extends JFrame{

	private JFrame pannelloadmin = new JFrame();
	private JPanel contentPane = new JPanel();
	private JList<Traccia> listaTracce = new JList<>();
	private DefaultListModel demoList = new DefaultListModel();
	private DefaultListModel demoList1 = new DefaultListModel();
	private ArrayList<Traccia> ListaTracce;
	private JList<Ascoltatore> listaUtenti = new JList<Ascoltatore>();
	private ArrayList<Ascoltatore> ListaUtenti;

	@SuppressWarnings("unchecked")
	public PannelloAdmin(JFrame impostazioni, Controller controller, Utente utente) {
		setResizable(false);
		
		impostazioni.setVisible(false);
		pannelloadmin = this;
		pannelloadmin.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1044, 660);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		pannelloadmin.setTitle("Pannello admin");
		

		Toolkit toolkit = getToolkit();
		Dimension size = toolkit.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
				
		
		JLabel AdminLB = new JLabel("Admin");
		AdminLB.setForeground(Color.WHITE);
		AdminLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		AdminLB.setHorizontalAlignment(SwingConstants.CENTER);
		AdminLB.setBounds(10, 11, 1008, 60);
		contentPane.add(AdminLB);
		
		JLabel TracceLB = new JLabel("Lista delle tracce:");
		TracceLB.setFont(new Font("Times New Roman", Font.BOLD, 25));
		TracceLB.setForeground(Color.WHITE);
		TracceLB.setBounds(35, 95, 202, 30);
		contentPane.add(TracceLB);
		
		JScrollPane scrollPaneTracce = new JScrollPane();
		scrollPaneTracce.setBounds(35, 136, 309, 338);
		contentPane.add(scrollPaneTracce);
		
		InizializzaList(controller);
		listaTracce.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				demoList1.removeAllElements();
			}
		});
		scrollPaneTracce.setViewportView(listaTracce);
		
		JLabel Cerca = new JLabel("");
		Cerca.setIcon(new ImageIcon(PannelloAdmin.class.getResource("/Immagini/PannelloAdmin/ricgreen.png")));
		Cerca.setHorizontalAlignment(SwingConstants.CENTER);
		Cerca.setForeground(Color.WHITE);
		Cerca.setFont(new Font("Times New Roman", Font.BOLD, 25));
		Cerca.setBounds(410, 252, 145, 99);
		contentPane.add(Cerca);
		
		
		JScrollPane scrollPaneListaUtenti = new JScrollPane();
		scrollPaneListaUtenti.setBounds(625, 136, 309, 338);
		contentPane.add(scrollPaneListaUtenti);
		listaUtenti.setFont(new Font("Times New Roman", Font.BOLD, 21));
		scrollPaneListaUtenti.setViewportView(listaUtenti);
		listaUtenti.setVisible(false);
		
		
		Cerca.addMouseListener(new MouseAdapter() {
		
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(listaTracce.getSelectedIndex()!=-1) {
				
				InizializzaListaUtenti(controller);	
				if(ListaTracce.get(listaTracce.getSelectedIndex()).CheckRemastering()) {
					JOptionPane.showMessageDialog(pannelloadmin, "Lista degli ascolti per remastering");
					
				}else if(ListaTracce.get(listaTracce.getSelectedIndex()).CheckCover()) {
					
					JOptionPane.showMessageDialog(pannelloadmin, "Lista degli ascolti per cover");
					
				}else {
					
					JOptionPane.showMessageDialog(pannelloadmin, "Lista degli ascolti per tracce originali");
					
				}
				
				
				listaUtenti.setVisible(true);
				listaTracce.clearSelection();
				
			}else {
					
					JOptionPane.showMessageDialog(pannelloadmin, "Non e' stata selezionata la traccia");
				}
		
			}
		
			@Override
			public void mouseEntered(MouseEvent e) {
				Cerca.setIcon(new ImageIcon(PannelloAdmin.class.getResource("/Immagini/PannelloAdmin/ricwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Cerca.setIcon(new ImageIcon(PannelloAdmin.class.getResource("/Immagini/PannelloAdmin/ricgreen.png")));
			}
		});
		
	
		
		JLabel UtentiConPiuAscolti = new JLabel("Lista di utenti con piu' ascolti per fascia oraria:");
		UtentiConPiuAscolti.setForeground(Color.WHITE);
		UtentiConPiuAscolti.setFont(new Font("Times New Roman", Font.BOLD, 23));
		UtentiConPiuAscolti.setBounds(526, 95, 470, 30);
		
		
		contentPane.add(UtentiConPiuAscolti);
		
		JLabel IndietroBTN = new JLabel("");
		IndietroBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliArtista/Indietrobtngreen.png")));
		IndietroBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				impostazioni.setVisible(true);
				System.out.println("Ti trovi in "+impostazioni.getClass().getSimpleName());
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				IndietroBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliArtista/Indietrobtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				IndietroBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliArtista/Indietrobtngreen.png")));
			}
		});
		
		IndietroBTN.setHorizontalAlignment(SwingConstants.CENTER);
		IndietroBTN.setForeground(Color.WHITE);
		IndietroBTN.setFont(new Font("Times New Roman", Font.BOLD, 25));
		IndietroBTN.setBounds(10, 561, 121, 49);
		contentPane.add(IndietroBTN);
		
		
		
		
		JLabel Sfondo = new JLabel("");
		Sfondo.setIcon(new ImageIcon(PannelloAdmin.class.getResource("/Immagini/back.jpg")));
		Sfondo.setBounds(0, 0, 1028, 621);
		contentPane.add(Sfondo);
		
		
		
		
		
	}
	

	private void InizializzaList(Controller controller) {
		
		ListaTracce = controller.RicavaTraccia("select * from traccia order by nometraccia;");
	
		int i;
		
		for(i=0; i<ListaTracce.size(); i++){
			demoList.addElement("Traccia: "+ListaTracce.get(i).getNomeTraccia()+"");
					
		}
		
		
		listaTracce.setModel(demoList);
	}
	
	
	private void InizializzaListaUtenti(Controller controller) {
		
		
		ListaUtenti = controller.RicavaAscoltatore("SELECT a.nickname, a.fasciaorariaascolto, count(*), tr.id_traccia FROM TRACCIA AS tr, ASCOLTATORE AS a WHERE tr.id_traccia = a.id_traccia and tr.id_traccia = '"+ListaTracce.get(listaTracce.getSelectedIndex()).getID_Traccia()+"' group by a.nickname, a.fasciaorariaascolto, tr.id_Traccia order by count desc limit 3");
	
		int j;
		
		for(j=0; j<ListaUtenti.size(); j++) {
			
			demoList1.addElement("Utente: "+ListaUtenti.get(j).getUtenteAscolto().getNickName()+"\n");	
			demoList1.addElement("Fascia: "+ListaUtenti.get(j).getFasciaOrariaAscolto());
			demoList1.addElement("\n");
		}
		
	
		
		listaUtenti.setModel(demoList1);
		
		
		
	}
}
