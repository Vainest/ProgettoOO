package Interfaccia;

import java.awt.EventQueue;



import Controller.Controller;


public class Avvio {
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					System.out.println("Avvio dell'interfaccia libreria musicale");
					Controller controller= new Controller();
					Login login= new Login(controller);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

}