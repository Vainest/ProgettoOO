package Interfaccia;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.*;
import Controller.Controller;
import ModelloUML.Album;
import ModelloUML.Traccia;
import ModelloUML.Utente;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class DettagliAlbum extends JFrame{

	private JFrame dettaglialbum;
	private JPanel contentPane;
	private JList<Album> listaAlbum = new JList<>();
	private DefaultListModel modelAlbum = new DefaultListModel();
	private ArrayList<Album> ListaAlbum;
	private JList<Traccia> listaTracce = new JList<>();
	private ArrayList<Traccia> ListaTracce;
	private DefaultListModel demoList = new DefaultListModel();

	/**
	 * Create the application.
	 */
	public DettagliAlbum(JFrame paginainiziale, Controller controller, JFrame pagprecedente, Utente utente, Album cerca) {
		setResizable(false);
		
		
		paginainiziale.setVisible(false);
		
		dettaglialbum = this;
		dettaglialbum.setVisible(true);
		System.out.println("Ti trovi in dettagli Album");	
		dettaglialbum.setTitle("Dettagli album");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dettaglialbum = new JFrame();
		setBounds(100, 100, 933, 602);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Toolkit toolkit = getToolkit();
		Dimension size = toolkit.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
		
		

		
		ListaTracceAlbum(controller,utente,cerca);
		
		
		
		JLabel TitoloAlLB = new JLabel("Titolo album");
		TitoloAlLB.setForeground(Color.WHITE);
		TitoloAlLB.setFont(new Font("Tahoma", Font.PLAIN, 29));
		TitoloAlLB.setHorizontalAlignment(SwingConstants.CENTER);
		TitoloAlLB.setBounds(118, 23, 702, 54);
		getContentPane().add(TitoloAlLB);
		TitoloAlLB.setText("Album: "+cerca.getArtistaAlbum().getNomeArtista());

		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(53, 135, 425, 311);
		contentPane.add(scrollPane);
		listaTracce.setFont(new Font("Times New Roman", Font.BOLD, 24));
		scrollPane.setViewportView(listaTracce);
		
		JLabel ListaTracceLB = new JLabel("Lista Tracce");
		ListaTracceLB.setForeground(Color.WHITE);
		ListaTracceLB.setFont(new Font("Times New Roman", Font.BOLD, 15));
		ListaTracceLB.setBounds(55, 99, 159, 36);
		contentPane.add(ListaTracceLB);
		
		JLabel ArtistaLB = new JLabel("Artista");
		ArtistaLB.setForeground(Color.WHITE);
		ArtistaLB.setFont(new Font("Times New Roman", Font.BOLD, 15));
		ArtistaLB.setBounds(499, 99, 159, 36);
		contentPane.add(ArtistaLB);
		
		JLabel AutoreLB = new JLabel("");
		AutoreLB.setForeground(Color.WHITE);
		AutoreLB.setFont(new Font("Times New Roman", Font.BOLD, 25));
		AutoreLB.setBounds(499, 143, 354, 65);
		contentPane.add(AutoreLB);
		AutoreLB.setText(""+cerca.getArtistaAlbum().getNomeArtista());
		
		JLabel DettagliTracciaBTN = new JLabel("");
		DettagliTracciaBTN.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/dettaglitrbtngreen.png")));
		DettagliTracciaBTN.setBounds(696, 437, 189, 90);
		contentPane.add(DettagliTracciaBTN);
		DettagliTracciaBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				   if(listaTracce.getSelectedIndex() != -1){
	                  
					    Traccia nome;
						nome = ListaTracce.get(listaTracce.getSelectedIndex());
							
						DettagliTraccia dettaglitraccia = new DettagliTraccia(paginainiziale, controller, DettagliAlbum.this, utente, nome);
						listaTracce.clearSelection();
						dispose();
			
				   }
				   
	                else{
	                	
	                	JOptionPane.showMessageDialog(contentPane, "Non hai selezionato la traccia", "Attento!", JOptionPane.WARNING_MESSAGE);
				
	                }	
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				DettagliTracciaBTN.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/dettaglitrbtnwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				DettagliTracciaBTN.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/dettaglitrbtngreen.png")));
			}
		});
		
		JLabel IndietroBTN1 = new JLabel("");
		IndietroBTN1.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/Indietrobtngreen.png")));
		IndietroBTN1.setBounds(10, 509, 107, 54);
		contentPane.add(IndietroBTN1);
		IndietroBTN1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				pagprecedente.setVisible(true);
				System.out.println("Ti trovi in "+pagprecedente.getClass().getSimpleName());
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				IndietroBTN1.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/Indietrobtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				IndietroBTN1.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/Indietrobtngreen.png")));
			}
		});
		
		JLabel PaginaInizialeBTN = new JLabel("");
		PaginaInizialeBTN.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/paginainizialebtngreen.png")));
		PaginaInizialeBTN.setBounds(126, 509, 167, 54);
		contentPane.add(PaginaInizialeBTN);
		PaginaInizialeBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				paginainiziale.setVisible(true);
				System.out.println("Ti trovi nella pagina iniziale");
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				PaginaInizialeBTN.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/paginainizialebtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				PaginaInizialeBTN.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/paginainizialebtngreen.png")));
			}
		});
		
		JLabel NBraniLB = new JLabel("Numero di brani:");
		NBraniLB.setForeground(Color.WHITE);
		NBraniLB.setFont(new Font("Times New Roman", Font.BOLD, 15));
		NBraniLB.setBounds(499, 223, 159, 36);
		contentPane.add(NBraniLB);
		
		JLabel RisNBraniLB = new JLabel("");
		RisNBraniLB.setForeground(Color.WHITE);
		RisNBraniLB.setFont(new Font("Times New Roman", Font.BOLD, 20));
		RisNBraniLB.setBounds(499, 286, 130, 36);
		contentPane.add(RisNBraniLB);
		RisNBraniLB.setText(""+cerca.getN_Brani());
		
		JLabel AnnoUscitaLB = new JLabel("Anno uscita:");
		AnnoUscitaLB.setForeground(Color.WHITE);
		AnnoUscitaLB.setFont(new Font("Times New Roman", Font.BOLD, 15));
		AnnoUscitaLB.setBounds(499, 347, 159, 36);
		contentPane.add(AnnoUscitaLB);
		
		JLabel RisAnnoUscitaLB = new JLabel("0");
		RisAnnoUscitaLB.setForeground(Color.WHITE);
		RisAnnoUscitaLB.setFont(new Font("Times New Roman", Font.BOLD, 20));
		RisAnnoUscitaLB.setBounds(499, 410, 159, 36);
		contentPane.add(RisAnnoUscitaLB);
		RisAnnoUscitaLB.setText(""+cerca.getAnnoUscita());
		
		JLabel TotMinutaggio = new JLabel("Tempo totale:");
		TotMinutaggio.setForeground(Color.WHITE);
		TotMinutaggio.setFont(new Font("Times New Roman", Font.BOLD, 15));
		TotMinutaggio.setBounds(726, 223, 159, 36);
		contentPane.add(TotMinutaggio);
		
		JLabel TempTotale = new JLabel("0");
		TempTotale.setForeground(Color.WHITE);
		TempTotale.setFont(new Font("Times New Roman", Font.BOLD, 20));
		TempTotale.setBounds(726, 286, 130, 36);
		contentPane.add(TempTotale);
		TempTotale.setText(""+cerca.getDurataAlbum());
		
		
		
		JLabel Sfondo = new JLabel("");
		Sfondo.setIcon(new ImageIcon(DettagliAlbum.class.getResource("/Immagini/DettagliAlbum/Sfondo.jpg")));
		Sfondo.setBounds(0, 0, 917, 563);
		contentPane.add(Sfondo);
		
		
		
		

		
		
		
		
		
		
	}
	
	private void ListaTracceAlbum(Controller controller, Utente utente, Album cerca) {
		
		ListaTracce = controller.RicavaTraccia("select * from traccia as tr, formatotraccia as ft, album as al where tr.id_traccia = ft.id_traccia and ft.id_album = al.id_album and al.nomealbum ilike '"+cerca.getNomeAlbum()+"';");
	
		int i;
		for(i=0; i<ListaTracce.size(); i++){
			demoList.addElement("Traccia: "+ListaTracce.get(i).getNomeTraccia()+" ");
		}
		
		listaTracce.setModel(demoList);
		
		
		
	}
}
	







