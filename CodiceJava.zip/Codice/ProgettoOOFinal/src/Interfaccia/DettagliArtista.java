package Interfaccia;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Controller.Controller;
import ModelloUML.Album;
import ModelloUML.Artista_T;
import ModelloUML.Traccia;
import ModelloUML.Utente;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;

public class DettagliArtista extends JFrame{

	private JFrame dettagliartista = new JFrame();
	private JPanel contentPane = new JPanel();
	private DefaultListModel demoList1 = new DefaultListModel();
	private DefaultListModel demoList2 = new DefaultListModel();
	private ArrayList<Traccia> ListaTracce;
	private ArrayList<Album> ListaAlbum;
	private JList<Traccia> listaTracce = new JList<>();
	private JList<Album> listaAlbum = new JList<>();
    private JLabel DettagliAlbumBTN = new JLabel("");
    private JLabel DettagliTracciaBTN = new JLabel("");

	public DettagliArtista(JFrame paginainiziale, Controller controller, JFrame pagprecedente, Utente utente, Artista_T nome) {
		setResizable(false);
		
		paginainiziale.setVisible(false);
		dettagliartista=this;
		dettagliartista.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 933, 602);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		System.out.println("Ti trovi in dettagli artista");
		dettagliartista.setTitle("Dettagli artista");
		
		Toolkit toolkit = getToolkit();
		Dimension size = toolkit.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
		
		
		JLabel NomeArtista = new JLabel("Artista: "+nome.getNomeArtista());
		NomeArtista.setHorizontalAlignment(SwingConstants.CENTER);
		NomeArtista.setForeground(Color.WHITE);
		NomeArtista.setFont(new Font("Times New Roman", Font.BOLD, 30));
		NomeArtista.setBounds(10, 31, 897, 76);
		contentPane.add(NomeArtista);
		
		JLabel IndietroBTN = new JLabel("");
		IndietroBTN.setIcon(new ImageIcon(DettagliArtista.class.getResource("/Immagini/DettagliArtista/Indietrobtngreen.png")));
		IndietroBTN.setBounds(10, 510, 102, 47);
		contentPane.add(IndietroBTN);
		IndietroBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				pagprecedente.setVisible(true);
				System.out.println("Ti trovi in "+pagprecedente.getClass().getSimpleName());
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				IndietroBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliArtista/Indietrobtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				IndietroBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliArtista/Indietrobtngreen.png")));
			}
		});
		
		
		
		
		
		JLabel PaginainizialeBTN = new JLabel("");
		PaginainizialeBTN.setIcon(new ImageIcon(DettagliArtista.class.getResource("/Immagini/DettagliArtista/paginainizialebtngreen.png")));
		PaginainizialeBTN.setBounds(122, 503, 167, 60);
		contentPane.add(PaginainizialeBTN);
		PaginainizialeBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				paginainiziale.setVisible(true);
				System.out.println("Ti trovi nella pagina iniziale");
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				PaginainizialeBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliArtista/paginainizialebtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				PaginainizialeBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliArtista/paginainizialebtngreen.png")));
			}
		});
		
		JLabel NazionalitaLB = new JLabel("Nazionalita: "+nome.getNazionalita());
		NazionalitaLB.setHorizontalAlignment(SwingConstants.LEFT);
		NazionalitaLB.setForeground(Color.WHITE);
		NazionalitaLB.setFont(new Font("Times New Roman", Font.BOLD, 28));
		NazionalitaLB.setBounds(38, 168, 402, 61);
		contentPane.add(NazionalitaLB);
		
		JLabel lblSesso = new JLabel("Sesso: "+nome.getSesso());
		lblSesso.setHorizontalAlignment(SwingConstants.LEFT);
		lblSesso.setForeground(Color.WHITE);
		lblSesso.setFont(new Font("Times New Roman", Font.BOLD, 28));
		lblSesso.setBounds(38, 241, 294, 61);
		contentPane.add(lblSesso);
		
		JLabel lblDataDiNascita = new JLabel("Data di nascita: "+nome.getDataNascita());
		lblDataDiNascita.setHorizontalAlignment(SwingConstants.LEFT);
		lblDataDiNascita.setForeground(Color.WHITE);
		lblDataDiNascita.setFont(new Font("Times New Roman", Font.BOLD, 28));
		lblDataDiNascita.setBounds(38, 314, 441, 61);
		contentPane.add(lblDataDiNascita);
		
		InizializzazioneListaAlbum(controller, nome);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(517, 153, 277, 231);
		contentPane.add(scrollPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setFont(new Font("Times New Roman", Font.BOLD, 11));
		scrollPane.setViewportView(tabbedPane);
		listaTracce.setForeground(Color.BLACK);
		listaTracce.setFont(new Font("Times New Roman", Font.BOLD, 20));
		
		
		tabbedPane.addTab("Tracce prodotte", null, listaTracce, null);
		listaAlbum.setFont(new Font("Times New Roman", Font.BOLD, 20));
		
		tabbedPane.addTab("Album incisi", null, listaAlbum, null);
		
		DettagliTracciaBTN.setIcon(new ImageIcon(DettagliArtista.class.getResource("/Immagini/DettagliArtista/dettaglitrbtngreen.png")));
		DettagliTracciaBTN.setBounds(493, 430, 196, 76);
		contentPane.add(DettagliTracciaBTN);
		DettagliTracciaBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				   if(listaTracce.getSelectedIndex() != -1){
	                  
					    Traccia nome;
						nome = ListaTracce.get(listaTracce.getSelectedIndex());
						DettagliTraccia dettaglitraccia = new DettagliTraccia(paginainiziale, controller, DettagliArtista.this, utente, nome);
						listaTracce.clearSelection();
						dispose();
						
				   }
				   
	                else{
	                	
	                	JOptionPane.showMessageDialog(contentPane, "Non hai selezionato la traccia", "Attento!", JOptionPane.WARNING_MESSAGE);
				
	                }	
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				DettagliTracciaBTN.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/DettagliArtista/dettaglitrbtnwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				DettagliTracciaBTN.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/DettagliArtista/dettaglitrbtngreen.png")));
			}
		});
		
	
		
			DettagliAlbumBTN.setIcon(new ImageIcon(DettagliArtista.class.getResource("/Immagini/DettagliArtista/dettagliAlbbtngreen.png")));
			DettagliAlbumBTN.setBounds(686, 430, 184, 76);
			contentPane.add(DettagliAlbumBTN);
			DettagliAlbumBTN.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					   if(listaAlbum.getSelectedIndex() != -1){
			                  
							Album nome;
							nome = ListaAlbum.get(listaAlbum.getSelectedIndex());
							DettagliAlbum dettaglialbum = new DettagliAlbum(paginainiziale, controller, DettagliArtista.this, utente, nome);
							listaAlbum.clearSelection();
							dispose();
							
					   }
					   
		                else{
		                	
		                	JOptionPane.showMessageDialog(contentPane, "Non hai selezionato l'album", "Attento!", JOptionPane.WARNING_MESSAGE);
					
		                }	
					
				
				}
				@Override
				public void mouseEntered(MouseEvent e) {
					DettagliAlbumBTN.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettagliAlbbtnwhite.png")));
				}
				@Override
				public void mouseExited(MouseEvent e) {
					DettagliAlbumBTN.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettagliAlbbtngreen.png")));
				}
			});
	
		
		
		
		
		
		JLabel Sfondo = new JLabel("");
		Sfondo.setIcon(new ImageIcon(DettagliArtista.class.getResource("/Immagini/DettagliArtista/Sfondo.jpg")));
		Sfondo.setBounds(0, 0, 917, 563);
		contentPane.add(Sfondo);
		
		
		
	}
	
	private void InizializzazioneListaAlbum(Controller controller, Artista_T nome) {
		
		
		ListaAlbum = controller.RicavaAlbum("select * from album where id_artista = '"+nome.getID_ArtistaT()+"';");
		int i;
		for(i=0; i<ListaAlbum.size(); i++) {
			
			demoList1.addElement(ListaAlbum.get(i).getNomeAlbum());
			
		}
		
		listaAlbum.setModel(demoList1);
		
		ListaTracce = controller.RicavaTraccia("select * from traccia where id_artista = '"+nome.getID_ArtistaT()+"';");
		for(i=0; i<ListaTracce.size(); i++) {
			
			demoList2.addElement(ListaTracce.get(i).getNomeTraccia());
			
		}
		
		listaTracce.setModel(demoList2);
		
		
		
	}
	
	
	
	
	
	
	
}
