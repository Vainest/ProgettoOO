package Interfaccia;



import java.time.ZoneId;
import java.time.LocalDate;
import java.time.Period;

import java.awt.Dimension;

import java.awt.Toolkit;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JDateChooser;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Color;


import Controller.Controller;

import javax.swing.JRadioButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;

public class Registrazione extends JFrame {

	private JPanel contentPane;
	public JFrame login;
	public JFrame registrazione;
	private JTextField NickNameField = new JTextField();;
	private JTextField NomeField = new JTextField();
	private JTextField CognomeField = new JTextField();
	private JTextField NazionalitaField = new JTextField();
	private JTextField PasswordField = new JTextField();
	private JTextField ConfermaPasswordField = new JTextField();
	private Controller controller;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JLabel ConfRegLB = new JLabel("");
	private JLabel IndietroLB = new JLabel("");
	private JLabel TitoloLB = new JLabel("");
	private JLabel NickNameLB = new JLabel("NickName:");
	private JLabel NomeLB = new JLabel("Nome:");
	private JLabel CognomeLB = new JLabel("Cognome:");
	private JLabel DataDiNascitaLB = new JLabel("Data di nascita:");
	private JLabel SessoLB = new JLabel("Sesso:");
	private JLabel NazionalitaLB = new JLabel("Nazionalita:");
	private JLabel PasswordLB = new JLabel("Password:");
	private JLabel ConfermaPasswordLB = new JLabel("Conferma Password:");
	private JLabel InserisciCredLB = new JLabel("");
	private JTextArea RisultatoArea = new JTextArea();
	private JDateChooser dateChooser = new JDateChooser();
	private JRadioButton Maschio = new JRadioButton("M");
	private JRadioButton Femmina = new JRadioButton("F");
	private JLabel ConfermaLB = new JLabel("");


	/**
	 * Create the frame.
	 */
	public Registrazione(Controller controller, JFrame login) {
		
		setTitle("Registrazione");
		System.out.println("Accesso in registrazione");
		registrazione = this;
		this.controller = controller;
		login.setVisible(false);
		this.setVisible(true);
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 830, 634);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		registrazione.setTitle("Registrazione");
		
		FinestraAlCentro();
		
		ConfRegLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/ConfReggreen.png")));
		ConfRegLB.setBounds(492, 474, 238, 95);
		contentPane.add(ConfRegLB);
		ConfRegLB.setVisible(false);
		ConfRegLB.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseEntered(MouseEvent e) {
				
				ConfRegLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/ConfRegwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				ConfRegLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/ConfReggreen.png")));
			}
			
		});
		
		
		IndietroLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Indietrobtngreen.png")));
		IndietroLB.setBounds(0, 556, 107, 39);
		contentPane.add(IndietroLB);
		IndietroLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				IndietroLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Indietrobtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				IndietroLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Indietrobtngreen.png")));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				
				login.setVisible(true);
				System.out.println("Log in");
				registrazione.dispose();
				
			}
		});
	
		
		TitoloLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/RegistrWaihona.png")));
		TitoloLB.setForeground(Color.WHITE);
		TitoloLB.setFont(new Font("Times New Roman", Font.BOLD, 30));
		TitoloLB.setHorizontalAlignment(SwingConstants.CENTER);
		TitoloLB.setBounds(27, 11, 744, 58);
		contentPane.add(TitoloLB);
		
		NickNameLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/NickName.png")));
		NickNameLB.setForeground(Color.WHITE);
		NickNameLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		NickNameLB.setBounds(79, 192, 96, 14);
		contentPane.add(NickNameLB);
		
		NomeLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Nome.png")));
		NomeLB.setForeground(Color.WHITE);
		NomeLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		NomeLB.setBounds(117, 223, 64, 14);
		contentPane.add(NomeLB);
		
		CognomeLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Cognome.png")));
		CognomeLB.setForeground(Color.WHITE);
		CognomeLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		CognomeLB.setBounds(91, 258, 90, 14);
		contentPane.add(CognomeLB);
		
		DataDiNascitaLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/DataNascita.png")));
		DataDiNascitaLB.setForeground(Color.WHITE);
		DataDiNascitaLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		DataDiNascitaLB.setBounds(32, 296, 144, 14);
		contentPane.add(DataDiNascitaLB);
		
		SessoLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Sesso.png")));
		SessoLB.setForeground(Color.WHITE);
		SessoLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		SessoLB.setBounds(117, 333, 56, 14);
		contentPane.add(SessoLB);
		
		NazionalitaLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Nazionalita.png")));
		NazionalitaLB.setForeground(Color.WHITE);
		NazionalitaLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		NazionalitaLB.setBounds(63, 370, 114, 14);
		contentPane.add(NazionalitaLB);
		
		PasswordLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Password.png")));
		PasswordLB.setForeground(Color.WHITE);
		PasswordLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		PasswordLB.setBounds(86, 406, 95, 14);
		contentPane.add(PasswordLB);
		
		ConfermaPasswordLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/ConfermaPsw.png")));
		ConfermaPasswordLB.setForeground(Color.WHITE);
		ConfermaPasswordLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		ConfermaPasswordLB.setBounds(-4, 448, 185, 14);
		contentPane.add(ConfermaPasswordLB);
		
		NickNameField.setBounds(180, 189, 133, 20);
		contentPane.add(NickNameField);
		NickNameField.setColumns(10);
		
		NomeField.setColumns(10);
		NomeField.setBounds(180, 220, 133, 20);
		contentPane.add(NomeField);
		
		CognomeField.setColumns(10);
		CognomeField.setBounds(180, 255, 133, 20);
		contentPane.add(CognomeField);
		
		NazionalitaField.setColumns(10);
		NazionalitaField.setBounds(180, 367, 133, 20);
		contentPane.add(NazionalitaField);
		
		PasswordField.setColumns(10);
		PasswordField.setBounds(180, 403, 133, 20);
		contentPane.add(PasswordField);
		
		ConfermaPasswordField.setColumns(10);
		ConfermaPasswordField.setBounds(180, 444, 133, 20);
		contentPane.add(ConfermaPasswordField);
		
		InserisciCredLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/InserisciCred.png")));
		InserisciCredLB.setForeground(Color.WHITE);
		InserisciCredLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		InserisciCredLB.setBounds(36, 137, 264, 30);
		contentPane.add(InserisciCredLB);
		
		RisultatoArea.setForeground(new Color(0, 128, 0));
		RisultatoArea.setFont(new Font("Book Antiqua", Font.BOLD, 20));
		RisultatoArea.setBounds(458, 189, 293, 234);
		contentPane.add(RisultatoArea);
		RisultatoArea.setEditable(false);

		dateChooser.setBounds(180, 293, 133, 20);
		contentPane.add(dateChooser);
		
		
		Maschio.setFont(new Font("Tahoma", Font.BOLD, 11));
		Maschio.setHorizontalAlignment(SwingConstants.CENTER);
		buttonGroup.add(Maschio);
		Maschio.setBounds(181, 330, 39, 23);
		contentPane.add(Maschio);
		
		Femmina.setFont(new Font("Tahoma", Font.BOLD, 11));
		Femmina.setHorizontalAlignment(SwingConstants.CENTER);
		buttonGroup.add(Femmina);
		Femmina.setBounds(222, 330, 39, 23);
		contentPane.add(Femmina);
		ButtonModel buttonModel = buttonGroup.getSelection();
		
		boolean admin = false;
			
		ConfermaLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Confermabtngreen.png")));
		ConfermaLB.setBounds(117, 495, 169, 58);
		contentPane.add(ConfermaLB);
		ConfermaLB.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseEntered(MouseEvent e) {
				
				ConfermaLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Confermabtnwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				ConfermaLB.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Confermabtngreen.png")));
			}
			
		});
		
		ConfermaLB.addMouseListener(new MouseAdapter() {
			@SuppressWarnings("deprecation")
			public void mouseClicked(MouseEvent e) {
				
				if(e.getSource() == ConfermaLB) {
					
					boolean NickEsistente;
					
					String nick = "NickName: "+NickNameField.getText()+"\n";
					String nome = "Nome: "+NomeField.getText()+"\n";
					String cognome = "Cognome: "+CognomeField.getText()+"\n";
					String sesso = null;
					String data = null;
					
					if(Maschio.isSelected())
						sesso = "\nSesso: M\n";
					else if(Femmina.isSelected())
						sesso = "\nSesso: F\n";
					
					

					String nazionalita = "Nazionalita: "+NazionalitaField.getText()+"\n";
					String password = "Password: "+PasswordField.getText()+"\n";
					
					
				if(NickNameField.getText().equals("") || NomeField.getText().equals("") || CognomeField.getText().equals("")
			    	|| dateChooser.getDate() == null || NazionalitaField.getText().equals("")
					|| PasswordField.getText().equals("") || ConfermaPasswordField.getText().equals("") || sesso == null) {
					
						
						JOptionPane.showMessageDialog(contentPane, "Non sono stati inseriti tutti"
								+ "i campi", "Attento!", JOptionPane.WARNING_MESSAGE);
				
						
					}else{
						
						LocalDate from = LocalDate.ofInstant(dateChooser.getDate().toInstant(), ZoneId.systemDefault());
						LocalDate currentTime = LocalDate.now();
						
						if((Period.between(from,currentTime).getYears())<18) {
						
							JOptionPane.showMessageDialog(contentPane, "Non sei maggiorenne"
									+ "", "Attento!", JOptionPane.WARNING_MESSAGE);
							
						}else {
							
					       StringBuilder stringBuilder = new StringBuilder();
							stringBuilder.append("Data: ");
							stringBuilder.append(dateChooser.getDate().getDate());
							stringBuilder.append("-");
							stringBuilder.append(dateChooser.getDate().getMonth()+1);
							stringBuilder.append("-");
							stringBuilder.append(dateChooser.getDate().getYear()+1900);
							data = stringBuilder.toString();
						
					if(PasswordField.getText().equals(ConfermaPasswordField.getText())) {
						
						NickEsistente = controller.CheckNickName(NickNameField.getText());
						
						if(!NickEsistente){
							
							
							RisultatoArea.setText(nick + nome + cognome + data + sesso + nazionalita + password);
							RisultatoArea.setEditable(false);
							ConfRegLB.setVisible(true);
							ConfRegLB.addMouseListener(new MouseAdapter() {
								@Override
								public void mouseClicked(MouseEvent e) {
									
									if(e.getSource() == ConfRegLB) {
										
										String sesso = null;
										if(Maschio.isSelected())
											sesso = "M";
										else
											sesso = "F";
										
									String data = ((dateChooser.getDate().getDate())+"-"+(dateChooser.getDate().getMonth()+1)+"-"+(dateChooser.getDate().getYear()+1900));
										
									int flag;
										
									flag = controller.RegistrazioneUtente(NickNameField.getText(), 
											PasswordField.getText(), NomeField.getText(), CognomeField.getText(), 
											data, sesso, NazionalitaField.getText(), admin);
									
									if(flag > 0){
										
										JOptionPane.showMessageDialog(contentPane, "Creazione avvenuta con successo!");
										login.setVisible(true);
										System.out.println("Accesso in login");
										registrazione.dispose();
										
										}
										
										
										
									}
									
								}
							});
						}else{
							
							JOptionPane.showMessageDialog(contentPane, "Il NickName è già esistente","Riprova!",JOptionPane.WARNING_MESSAGE);
							}
						
					
					  }else{
						  
						  JOptionPane.showMessageDialog(contentPane, "Le password non coincidono","Riprova!",JOptionPane.WARNING_MESSAGE);
						  
					  	}				
					}
				}
			}
		}
				
});
		
		
		
		
		JLabel Background = new JLabel("");
		Background.setIcon(new ImageIcon(Registrazione.class.getResource("/Immagini/Registrazione/Regbackground.jpg")));
		Background.setBounds(0, 0, 814, 595);
		contentPane.add(Background);
		
		
		
		
	}
	
	
	
private void FinestraAlCentro() {

		
		Toolkit toolkit = getToolkit();
		Dimension size = toolkit.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
		
	}




	
}
