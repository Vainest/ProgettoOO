package Interfaccia;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Controller.Controller;
import ModelloUML.Utente;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Impostazioni extends JFrame{

	private JFrame impostazioni = new JFrame();
	private JPanel contentPane = new JPanel();
	private JTextField NicknameField;
	private JTextField PasswordField;
	private JPasswordField passwordField;

	private JLabel ConfermaCredLB = new JLabel("");
	private JTextField NomeField;
	private JTextField CognomeField;
	private String nick;
	
	public Impostazioni(JFrame paginainiziale, JFrame login ,Controller controller, Utente utente) {
		setResizable(false);
		
		paginainiziale.setVisible(false);
		impostazioni=this;
		impostazioni.setVisible(true);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 933, 602);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		System.out.println("Ti trovi in impostazioni");
		impostazioni.setTitle("Impostazioni");
		
		Toolkit toolkit = getToolkit();
		Dimension size = toolkit.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
		
		JLabel PaginaInizialeBTN = new JLabel("");
		PaginaInizialeBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/paginainizialebtngreen.png")));
		PaginaInizialeBTN.setBounds(10, 502, 167, 50);
		contentPane.add(PaginaInizialeBTN);
		PaginaInizialeBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				paginainiziale.setVisible(true);
				System.out.println("Ti trovi nella pagina iniziale");
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				PaginaInizialeBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/paginainizialebtnwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				PaginaInizialeBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/paginainizialebtngreen.png")));
				
			}
		});
		
		
		
		
		
		
		
		JLabel NickNameLB = new JLabel("");
		NickNameLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/NickName.png")));
		NickNameLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		NickNameLB.setForeground(Color.WHITE);
		NickNameLB.setBounds(35, 87, 159, 38);
		contentPane.add(NickNameLB);
		
		JLabel PasswordLB = new JLabel("");
		PasswordLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/Password.png")));
		PasswordLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		PasswordLB.setForeground(Color.WHITE);
		PasswordLB.setBounds(35, 202, 167, 38);
		contentPane.add(PasswordLB);
		
		JLabel SessoLB = new JLabel("");
		SessoLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/Sesso.png")));
		SessoLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		SessoLB.setForeground(Color.WHITE);
		SessoLB.setBounds(35, 322, 167, 38);
		contentPane.add(SessoLB);
		
		JLabel NazionalitaLB = new JLabel("");
		NazionalitaLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/Nazionalita.png")));
		NazionalitaLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		NazionalitaLB.setForeground(Color.WHITE);
		NazionalitaLB.setBounds(314, 322, 167, 38);
		contentPane.add(NazionalitaLB);
		
		JLabel DataDiNascitaLB = new JLabel("");
		DataDiNascitaLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/DataNascita.png")));
		DataDiNascitaLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		DataDiNascitaLB.setForeground(Color.WHITE);
		DataDiNascitaLB.setBounds(578, 87, 167, 38);
		contentPane.add(DataDiNascitaLB);
		
		NicknameField = new JTextField();
		NicknameField.setForeground(Color.BLACK);
		NicknameField.setFont(new Font("Times New Roman", Font.BOLD, 17));
		NicknameField.setBounds(44, 134, 167, 30);
		contentPane.add(NicknameField);
		NicknameField.setColumns(10);
		NicknameField.setText(utente.getNickName());
		NicknameField.setEditable(false);
		nick = NicknameField.getText();
		
		
		PasswordField = new JTextField();
		PasswordField.setForeground(Color.BLACK);
		PasswordField.setFont(new Font("Times New Roman", Font.BOLD, 17));
		PasswordField.setColumns(10);
		PasswordField.setBounds(44, 251, 167, 30);
		contentPane.add(PasswordField);
		
		PasswordField.setText(utente.getPassword());
		PasswordField.setEditable(false);
		
		
		JLabel RisSessoLB = new JLabel("");
		RisSessoLB.setFont(new Font("Times New Roman", Font.BOLD, 23));
		RisSessoLB.setForeground(Color.WHITE);
		RisSessoLB.setBounds(44, 371, 167, 30);
		contentPane.add(RisSessoLB);
		
		RisSessoLB.setText(utente.getSessoUtente());
		
		JLabel RisDataNascitaLB = new JLabel("");
		RisDataNascitaLB.setFont(new Font("Times New Roman", Font.BOLD, 23));
		RisDataNascitaLB.setForeground(Color.WHITE);
		RisDataNascitaLB.setBounds(589, 136, 167, 30);
		contentPane.add(RisDataNascitaLB);
		
		RisDataNascitaLB.setText(""+utente.getDataDiNascita()+"");
		
		JLabel RisNazionalitaLB = new JLabel("");
		RisNazionalitaLB.setFont(new Font("Times New Roman", Font.BOLD, 23));
		RisNazionalitaLB.setForeground(Color.WHITE);
		RisNazionalitaLB.setBounds(327, 371, 167, 30);
		contentPane.add(RisNazionalitaLB);
		
		RisNazionalitaLB.setText(utente.getNazionalita());
		
		JLabel ImpostazioniLB = new JLabel("");
		ImpostazioniLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/impostazioni.png")));
		ImpostazioniLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		ImpostazioniLB.setForeground(Color.WHITE);
		ImpostazioniLB.setHorizontalAlignment(SwingConstants.CENTER);
		ImpostazioniLB.setBounds(10, 11, 897, 38);
		contentPane.add(ImpostazioniLB);
		
		JLabel NomeLB = new JLabel("");
		NomeLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/Nome.png")));
		NomeLB.setForeground(Color.WHITE);
		NomeLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		NomeLB.setBounds(314, 87, 167, 38);
		contentPane.add(NomeLB);
		
		JLabel CognomeLB = new JLabel("");
		CognomeLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/Cognome.png")));
		CognomeLB.setForeground(Color.WHITE);
		CognomeLB.setFont(new Font("Times New Roman", Font.BOLD, 24));
		CognomeLB.setBounds(314, 202, 167, 38);
		contentPane.add(CognomeLB);
		
		JLabel ModificaCredLB = new JLabel("");
		ModificaCredLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/ModificaCredwhite.png")));
		ModificaCredLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				NicknameField.setEditable(true);
				PasswordField.setEditable(true);
				NomeField.setEditable(true);
				CognomeField.setEditable(true);
				ConfermaCredLB.setVisible(true);
				
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				ModificaCredLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/ModificaCredgreen.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				ModificaCredLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/ModificaCredwhite.png")));
			}
		});
		ModificaCredLB.setForeground(Color.WHITE);
		ModificaCredLB.setFont(new Font("Times New Roman", Font.BOLD, 30));
		ModificaCredLB.setHorizontalAlignment(SwingConstants.CENTER);
		ModificaCredLB.setBounds(537, 251, 329, 67);
		contentPane.add(ModificaCredLB);
		ConfermaCredLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/confermamodifichewhite.png")));
		
	
		ConfermaCredLB.setVisible(false);
		ConfermaCredLB.setHorizontalAlignment(SwingConstants.CENTER);
		ConfermaCredLB.setForeground(Color.WHITE);
		ConfermaCredLB.setFont(new Font("Times New Roman", Font.BOLD, 30));
		ConfermaCredLB.setBounds(547, 338, 319, 67);
		contentPane.add(ConfermaCredLB);
		ConfermaCredLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(NicknameField.getText().equals("") || PasswordField.getText().equals("") || NomeField.getText().equals("") || CognomeField.getText().equals("")) {
					
					JOptionPane.showMessageDialog(contentPane, "Sono presenti dei campi vuoti", "Attento!", JOptionPane.WARNING_MESSAGE);
					
				}else {
					
				
				NicknameField.setEditable(false);
				PasswordField.setEditable(false);
				NomeField.setEditable(false);
				CognomeField.setEditable(false);
				ConfermaCredLB.setVisible(false);
				
			boolean flagcheck = false;
			int flagagg = 0;
			
			
			if(!nick.equals(NicknameField.getText())) {
			
				flagcheck = controller.CheckNickName(NicknameField.getText());
				
				if(flagcheck) {
					
					JOptionPane.showMessageDialog(impostazioni, "Nickname gia' esistente");
					Impostazioni impost = new Impostazioni(paginainiziale,  login , controller, utente);
					dispose();
					
				}else {
					
				flagagg	= controller.AggiornaDati(NicknameField.getText(), PasswordField.getText(), NomeField.getText(), CognomeField.getText(), false, utente.getNickName());
					
				if(flagagg == 1) {
					
					JOptionPane.showMessageDialog(impostazioni, "Modifica avvenuta con successo, sarai riportato al login");
					login.setVisible(true);
					System.out.println("Sei ritornato al login");
					dispose();
					
					
				}else {
					
					JOptionPane.showMessageDialog(impostazioni, "Modifica non avvenuta");
					Impostazioni impost = new Impostazioni(paginainiziale,  login , controller, utente);
					dispose();
					
					
				}
						
					
			}
				
		}else {
			
			
			flagagg	= controller.AggiornaDati(NicknameField.getText(), PasswordField.getText(), NomeField.getText(), CognomeField.getText(), false, utente.getNickName());
			
			if(flagagg == 1) {
				
				JOptionPane.showMessageDialog(impostazioni, "Modifica avvenuta con successo, sarai riportato al login");
				login.setVisible(true);
				System.out.println("Sei ritornato al login");
				dispose();
				
				
			}else {
				
				JOptionPane.showMessageDialog(impostazioni, "Modifica non avvenuta");
				Impostazioni impost = new Impostazioni(paginainiziale,  login , controller, utente);
				dispose();
				
				
			}
			
			
		}
				
	}		
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				ConfermaCredLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/confermamodifichegreen.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				ConfermaCredLB.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/confermamodifichewhite.png")));
			}
		});
		
		NomeField = new JTextField();
		NomeField.setForeground(Color.BLACK);
		NomeField.setFont(new Font("Times New Roman", Font.BOLD, 17));
		NomeField.setEditable(false);
		NomeField.setColumns(10);
		NomeField.setBounds(327, 134, 167, 30);
		contentPane.add(NomeField);
		NomeField.setText(utente.getNome());
		
		CognomeField = new JTextField();
		CognomeField.setForeground(Color.BLACK);
		CognomeField.setFont(new Font("Times New Roman", Font.BOLD, 17));
		CognomeField.setEditable(false);
		CognomeField.setColumns(10);
		CognomeField.setBounds(327, 251, 167, 30);
		contentPane.add(CognomeField);
		CognomeField.setText(utente.getCognome());
		
		JLabel EliminaBTN = new JLabel("Elimina account");
		EliminaBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/elimaccgreen.png")));
		EliminaBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				int flagelim = 0;
				
				flagelim = controller.EliminaUtente(utente.getNickName());
				
				if(flagelim == 1) {
					
				JOptionPane.showMessageDialog(impostazioni, "Eliminazione avvenuta con successo");
				login.setVisible(true);
				System.out.println("Sei ritornato al login");
				dispose();
					
				}else {
					
					JOptionPane.showMessageDialog(impostazioni, "Eliminazione non andata a buon fine");
					
				}
				
				
				
			}
				
			@Override
			public void mouseEntered(MouseEvent e) {
				EliminaBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/elimaccwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				EliminaBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/elimaccgreen.png")));
			}
		});
		EliminaBTN.setForeground(Color.WHITE);
		EliminaBTN.setFont(new Font("Times New Roman", Font.BOLD, 22));
		EliminaBTN.setBounds(734, 485, 173, 67);
		contentPane.add(EliminaBTN);
		
		
		
		if(utente.CheckAdmin()) {
			
			
			JLabel OpzAdminBTN = new JLabel("");
			OpzAdminBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/opzadmgreen.png")));
		OpzAdminBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				PannelloAdmin pannelloadmin = new PannelloAdmin(impostazioni, controller, utente);
				dispose();
				
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				OpzAdminBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/opzadmwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				OpzAdminBTN.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/opzadmgreen.png")));
			}
		});
		OpzAdminBTN.setForeground(Color.WHITE);
		OpzAdminBTN.setFont(new Font("Times New Roman", Font.BOLD, 22));
		OpzAdminBTN.setBounds(589, 485, 135, 67);
		contentPane.add(OpzAdminBTN);
			
		
		}

		
		
		
		JLabel Sfondo = new JLabel("");
		Sfondo.setIcon(new ImageIcon(Impostazioni.class.getResource("/Immagini/Impostazioni/Sfondo.jpg")));
		Sfondo.setBounds(0, 0, 917, 563);
		contentPane.add(Sfondo);
		
		
	}
}
