package Interfaccia;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Controller.Controller;
import ModelloUML.BraniPreferiti;
import ModelloUML.Traccia;
import ModelloUML.Utente;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DettagliTraccia extends JFrame{

	private JFrame dettaglitraccia = new JFrame();
	private JPanel contentPane;
	private BraniPreferiti braniprefe;

	
	public DettagliTraccia(JFrame paginainiziale, Controller controller, JFrame indietro,Utente utente , Traccia nome) {
		setResizable(false);



		paginainiziale.setVisible(false);
		dettaglitraccia=this;
		dettaglitraccia.setVisible(true);
		System.out.println("Ti trovi in dettagli traccia");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dettaglitraccia.setTitle("Dettagli traccia");
		 
		
		
		setBounds(100, 100, 933, 602);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Toolkit toolkit = getToolkit();
		Dimension size = toolkit.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
		
		
		JLabel TitoloLB = new JLabel("Traccia: "+nome.getNomeTraccia());
		TitoloLB.setForeground(Color.WHITE);
		TitoloLB.setHorizontalAlignment(SwingConstants.CENTER);
		TitoloLB.setFont(new Font("Times New Roman", Font.BOLD, 28));
		TitoloLB.setBounds(33, 34, 838, 61);
		contentPane.add(TitoloLB);
		
		JLabel AnnoProdLB = new JLabel("Anno produzione: "+nome.getAnnoProduzione());
		AnnoProdLB.setForeground(Color.WHITE);
		AnnoProdLB.setHorizontalAlignment(SwingConstants.LEFT);
		AnnoProdLB.setFont(new Font("Times New Roman", Font.BOLD, 28));
		AnnoProdLB.setBounds(33, 149, 328, 61);
		contentPane.add(AnnoProdLB);
		
		
		JLabel DurataLB = new JLabel("Durata: "+nome.getDurata());
		DurataLB.setForeground(Color.WHITE);
		DurataLB.setHorizontalAlignment(SwingConstants.LEFT);
		DurataLB.setFont(new Font("Times New Roman", Font.BOLD, 28));
		DurataLB.setBounds(33, 222, 315, 61);
		contentPane.add(DurataLB);
		
		JLabel GenereLB = new JLabel("Genere: "+nome.getGenere());
		GenereLB.setForeground(Color.WHITE);
		GenereLB.setHorizontalAlignment(SwingConstants.LEFT);
		GenereLB.setFont(new Font("Times New Roman", Font.BOLD, 28));
		GenereLB.setBounds(33, 295, 296, 61);
		contentPane.add(GenereLB);

	
		
		JLabel ArtistaTrLB = new JLabel("Artista della traccia: "+nome.getArtistaTraccia().getNomeArtista());
		ArtistaTrLB.setForeground(Color.WHITE);
		ArtistaTrLB.setHorizontalAlignment(SwingConstants.LEFT);
		ArtistaTrLB.setFont(new Font("Times New Roman", Font.BOLD, 25));
		ArtistaTrLB.setBounds(358, 240, 549, 61);
		contentPane.add(ArtistaTrLB);
		
		
		JLabel IndietroBTN = new JLabel("");
		IndietroBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				indietro.setVisible(true);
				System.out.println("Ti trovi in "+indietro.getClass().getSimpleName());
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				IndietroBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/Indietrobtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				IndietroBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/Indietrobtngreen.png")));
			}
		});
		IndietroBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/Indietrobtngreen.png")));
		IndietroBTN.setBounds(20, 502, 106, 50);
		contentPane.add(IndietroBTN);
		
		JLabel PaginaInizialeBTN = new JLabel("");
		PaginaInizialeBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				paginainiziale.setVisible(true);
				System.out.println("Ti trovi nella pagina iniziale");
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				PaginaInizialeBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/paginainizialebtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				PaginaInizialeBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/paginainizialebtngreen.png")));
			}
		});
		PaginaInizialeBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/paginainizialebtngreen.png")));
		PaginaInizialeBTN.setBounds(139, 502, 167, 50);
		contentPane.add(PaginaInizialeBTN);
		
		JLabel AscoltaBTN = new JLabel("");
		AscoltaBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//ASCOLTO CANZONE
				int flag = controller.InserisciAscoltatore(nome, utente);
				
				if(flag == 1) {
					JOptionPane.showMessageDialog(dettaglitraccia, "Brano ascoltato!");
					System.out.println("Brano ascoltato con successo");
					DettagliTraccia dettaglitr = new DettagliTraccia(paginainiziale, controller,indietro,utente , nome);
					dispose();
					
				}else {
					
					System.out.println("Riproduzione non andata a buon fine");
					
				}
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				AscoltaBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/Ascoltabtnwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				AscoltaBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/Ascoltabtngreen.png")));
			}
		});
		AscoltaBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/Ascoltabtngreen.png")));
		AscoltaBTN.setBounds(727, 424, 112, 84);
		contentPane.add(AscoltaBTN);
		
		
		JLabel NtotaleAscLB = new JLabel("Numero totale di ascolti: "+nome.getN_TotaliAscolti());
		NtotaleAscLB.setForeground(Color.WHITE);
		NtotaleAscLB.setHorizontalAlignment(SwingConstants.LEFT);
		NtotaleAscLB.setFont(new Font("Times New Roman", Font.BOLD, 28));
		NtotaleAscLB.setBounds(33, 368, 407, 61);
		contentPane.add(NtotaleAscLB);
		
		
		
		JLabel Tipo = new JLabel("");
		Tipo.setFont(new Font("Times New Roman", Font.BOLD, 20));
		Tipo.setForeground(Color.WHITE);
		Tipo.setBounds(382, 293, 525, 61);
		contentPane.add(Tipo);
		
		if(nome.CheckCover() == true) {
			Tipo.setText("La traccia e' una cover");
		}else if(nome.CheckRemastering() == true) {
			Tipo.setText("La traccia e' un remastering");
		}
		
		InizializzaBraniP(controller,utente);
		JLabel AggiungiAiPrefeBTN = new JLabel("");
		AggiungiAiPrefeBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/btnagggreen.png")));
		AggiungiAiPrefeBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int flag = 0;
		
				flag = controller.AggiungiAiBraniPrefe("Insert into contienetracce values ('"+nome.getID_Traccia()+"','"+braniprefe.getID_BraniPreferiti()+"');");
				
				if(flag == 1) {
					
					JOptionPane.showMessageDialog(dettaglitraccia, "La traccia e' stata aggiunta ai brani preferiti!");
					
				}else {
					
					JOptionPane.showMessageDialog(dettaglitraccia, "La traccia non e' stata aggiunta ai brani preferiti!");
					
				}
		
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				AggiungiAiPrefeBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/btnaggwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				AggiungiAiPrefeBTN.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/btnagggreen.png")));
			}
		});
		AggiungiAiPrefeBTN.setForeground(Color.WHITE);
		AggiungiAiPrefeBTN.setFont(new Font("Times New Roman", Font.BOLD, 20));
		AggiungiAiPrefeBTN.setHorizontalAlignment(SwingConstants.CENTER);
		AggiungiAiPrefeBTN.setBounds(669, 352, 217, 64);
		contentPane.add(AggiungiAiPrefeBTN);
		
		
		
		JLabel Sfondo = new JLabel("");
		Sfondo.setIcon(new ImageIcon(DettagliTraccia.class.getResource("/Immagini/DettagliTraccia/Sfondo.jpg")));
		Sfondo.setBounds(0, 0, 917, 563);
		contentPane.add(Sfondo);
		
		
		
		
		
	}
	
	private void InizializzaBraniP(Controller controller, Utente utente) {
		
		braniprefe = controller.RicavaBraniPreferiti("select * from branipreferiti as bp, utente as ut where ut.nickname = bp.nickname and bp.nickname = '"+utente.getNickName()+"';");
		
		
		}
	
	
	
	
}
