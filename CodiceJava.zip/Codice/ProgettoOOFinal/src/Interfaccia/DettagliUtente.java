package Interfaccia;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Controller.Controller;
import ModelloUML.BraniPreferiti;
import ModelloUML.Traccia;
import ModelloUML.Utente;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DettagliUtente extends JFrame{


	private JPanel contentPane;
	private JFrame dettagliutente;
	private JList<Utente> listaUtenti = new JList<>();
	private DefaultListModel demoList = new DefaultListModel();
	private ArrayList<Utente> ListaUtenti;
	private Utente utenteric;
	private int x;
	
	public DettagliUtente(JFrame paginainiziale, Utente utente, Controller controller, JFrame indietro, String cerca) {
		setResizable(false);
		

		paginainiziale.setVisible(false);
		dettagliutente=this;
		dettagliutente.setVisible(true);
		System.out.println("Ti trovi in dettagli utente");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dettagliutente.setTitle("Dettagli utente");
		 
		
		dettagliutente = new JFrame();
		setBounds(100, 100, 933, 602);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Toolkit toolkit = getToolkit();
		Dimension size = toolkit.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
		
		
		JLabel NickNameLB = new JLabel("NickName");
		NickNameLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/NickName.png")));
		NickNameLB.setForeground(Color.WHITE);
		NickNameLB.setFont(new Font("Tahoma", Font.PLAIN, 19));
		NickNameLB.setBounds(61, 95, 98, 51);
		contentPane.add(NickNameLB);
		
		JLabel NomeLB = new JLabel("Nome");
		NomeLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/Nome.png")));
		NomeLB.setForeground(Color.WHITE);
		NomeLB.setFont(new Font("Tahoma", Font.PLAIN, 19));
		NomeLB.setBounds(95, 157, 64, 51);
		contentPane.add(NomeLB);
		
		JLabel CognomeLB = new JLabel("Cognome");
		CognomeLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/Cognome.png")));
		CognomeLB.setForeground(Color.WHITE);
		CognomeLB.setFont(new Font("Tahoma", Font.PLAIN, 19));
		CognomeLB.setBounds(69, 219, 90, 51);
		contentPane.add(CognomeLB);
		
		JLabel SessoLB = new JLabel("Sesso");
		SessoLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/Sesso.png")));
		SessoLB.setForeground(Color.WHITE);
		SessoLB.setFont(new Font("Tahoma", Font.PLAIN, 19));
		SessoLB.setBounds(102, 281, 57, 51);
		contentPane.add(SessoLB);
		
		JLabel NazionalitaLB = new JLabel("Nazionalita");
		NazionalitaLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/Nazionalita.png")));
		NazionalitaLB.setForeground(Color.WHITE);
		NazionalitaLB.setFont(new Font("Tahoma", Font.PLAIN, 19));
		NazionalitaLB.setBounds(45, 343, 114, 51);
		contentPane.add(NazionalitaLB);
		
		
		JLabel RisDataLB = new JLabel("");
		RisDataLB.setForeground(Color.WHITE);
		RisDataLB.setHorizontalAlignment(SwingConstants.LEFT);
		RisDataLB.setFont(new Font("Times New Roman", Font.BOLD, 19));
		RisDataLB.setBounds(292, 219, 274, 51);
		contentPane.add(RisDataLB);
		
		JLabel RisNomeLB = new JLabel("");
		RisNomeLB.setForeground(Color.WHITE);
		RisNomeLB.setHorizontalAlignment(SwingConstants.LEFT);
		RisNomeLB.setFont(new Font("Times New Roman", Font.BOLD, 19));
		RisNomeLB.setBounds(292, 95, 274, 51);
		contentPane.add(RisNomeLB);
		
		JLabel RisCognomeLB = new JLabel("");
		RisCognomeLB.setForeground(Color.WHITE);
		RisCognomeLB.setHorizontalAlignment(SwingConstants.LEFT);
		RisCognomeLB.setFont(new Font("Times New Roman", Font.BOLD, 19));
		RisCognomeLB.setBounds(292, 157, 274, 51);
		contentPane.add(RisCognomeLB);
		
		JLabel RisSessoLB = new JLabel("");
		RisSessoLB.setForeground(Color.WHITE);
		RisSessoLB.setHorizontalAlignment(SwingConstants.LEFT);
		RisSessoLB.setFont(new Font("Times New Roman", Font.BOLD, 19));
		RisSessoLB.setBounds(292, 281, 274, 51);
		contentPane.add(RisSessoLB);
		
		JLabel RisNazionLB = new JLabel("");
		RisNazionLB.setForeground(Color.WHITE);
		RisNazionLB.setHorizontalAlignment(SwingConstants.LEFT);
		RisNazionLB.setFont(new Font("Times New Roman", Font.BOLD, 19));
		RisNazionLB.setBounds(292, 343, 274, 51);
		contentPane.add(RisNazionLB);
		
			
	if(cerca.equals("")) {
			
			NazionalitaLB.setVisible(false);
			SessoLB.setVisible(false);
			CognomeLB.setVisible(false);
			NomeLB.setVisible(false);
			NickNameLB.setVisible(false);
			
			 InizializzaList(controller,utente);
			 
			 JScrollPane scrollPane = new JScrollPane();
			 scrollPane.setBounds(103, 95, 182, 309);
			 contentPane.add(scrollPane);
			 scrollPane.setViewportView(listaUtenti);
			 listaUtenti.setFont(new Font("Times New Roman", Font.BOLD, 20));
			 
			 listaUtenti.getSelectionModel().addListSelectionListener(e -> {
				    
				 x = listaUtenti.getSelectedIndex();
				 ListaUtenti.get(listaUtenti.getSelectedIndex());
				 	
				 
		            RisNomeLB.setText("Nome: " + ListaUtenti.get(x).getNome() + " \n");
		            RisCognomeLB.setText("Cognome: "+ListaUtenti.get(x).getCognome()+"\n");
		            RisDataLB.setText("Data di nascita: "+ListaUtenti.get(x).getDataDiNascita()+" \n");
		            RisSessoLB.setText("Sesso: "+ListaUtenti.get(x).getSessoUtente()+"\n");
		            RisNazionLB.setText("Nazionalita: "+ListaUtenti.get(x).getNazionalita());
		            
		            
			 });
			 
				JLabel BraniPrefeLB = new JLabel("");
				BraniPrefeLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/braniprefebtngreen.png")));
				BraniPrefeLB.setBounds(618, 219, 274, 101);
				contentPane.add(BraniPrefeLB);
				BraniPrefeLB.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						  if(listaUtenti.getSelectedIndex() != -1){
			                  
							  utenteric = ListaUtenti.get(listaUtenti.getSelectedIndex());
						
						boolean flag;
						if(utenteric.getNickName().equals(utente.getNickName()))
							flag = true;
						else
							flag = false;
						
						
						DettagliBraniPrefe dettaglibraniprefe = new DettagliBraniPrefe(paginainiziale, utenteric,controller, DettagliUtente.this, flag);
						dispose();
						
						   }
						   
			                else{
			                	
			                	JOptionPane.showMessageDialog(contentPane, "Non hai selezionato l'utente", "Attento!", JOptionPane.WARNING_MESSAGE);
						
			                }
					
						
					}
					@Override
					public void mouseEntered(MouseEvent e) {
						BraniPrefeLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/braniprefebtnwhite.png")));
					}
					@Override
					public void mouseExited(MouseEvent e) {
						BraniPrefeLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/braniprefebtngreen.png")));
					}
				});
			 
		
		}else {
			
			RisDataLB.setVisible(false);
			RisNomeLB.setVisible(false);
			RisCognomeLB.setVisible(false);
			RisSessoLB.setVisible(false);
			RisNazionLB.setVisible(false);
			
			ListaUtenti = controller.RicavaUtenti("select * from utente where nickname ilike '"+cerca+"%';");
			
			JLabel NickRis = new JLabel(ListaUtenti.get(0).getNickName());
			NickRis.setForeground(Color.WHITE);
			NickRis.setFont(new Font("Times New Roman", Font.BOLD, 24));
			NickRis.setBounds(187, 95, 200, 51);
			contentPane.add(NickRis);
			
			JLabel NomeRis = new JLabel(ListaUtenti.get(0).getNome());
			NomeRis.setForeground(Color.WHITE);
			NomeRis.setFont(new Font("Times New Roman", Font.BOLD, 24));
			NomeRis.setBounds(187, 157, 200, 51);
			contentPane.add(NomeRis);
			
			JLabel CognomeRis = new JLabel(ListaUtenti.get(0).getCognome());
			CognomeRis.setForeground(Color.WHITE);
			CognomeRis.setFont(new Font("Times New Roman", Font.BOLD, 24));
			CognomeRis.setBounds(187, 219, 200, 51);
			contentPane.add(CognomeRis);
			
			JLabel SessoRis = new JLabel(ListaUtenti.get(0).getSessoUtente());
			SessoRis.setForeground(Color.WHITE);
			SessoRis.setFont(new Font("Times New Roman", Font.BOLD, 24));
			SessoRis.setBounds(187, 281, 200, 51);
			contentPane.add(SessoRis);
			
			JLabel NazionalitaRis = new JLabel(ListaUtenti.get(0).getNazionalita());
			NazionalitaRis.setForeground(Color.WHITE);
			NazionalitaRis.setFont(new Font("Times New Roman", Font.BOLD, 24));
			NazionalitaRis.setBounds(187, 343, 200, 51);
			contentPane.add(NazionalitaRis);
			
			
			JLabel BraniPrefe1LB = new JLabel("");
			BraniPrefe1LB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/braniprefebtngreen.png")));
			BraniPrefe1LB.setBounds(618, 219, 274, 101);
			contentPane.add(BraniPrefe1LB);
			BraniPrefe1LB.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					utenteric = ListaUtenti.get(0);
					DettagliBraniPrefe dettaglibraniprefe = new DettagliBraniPrefe(paginainiziale, utenteric,controller, DettagliUtente.this, true);
					
					dispose();
				}
				@Override
				public void mouseEntered(MouseEvent e) {
					BraniPrefe1LB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/braniprefebtnwhite.png")));
				}
				@Override
				public void mouseExited(MouseEvent e) {
					BraniPrefe1LB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/braniprefebtngreen.png")));
				}
			});
			
			
			
			
		}
		
		JLabel TornaIndietroLB = new JLabel("");
		
		TornaIndietroLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/Indietrobtngreen.png")));
		TornaIndietroLB.setBounds(10, 501, 107, 51);
		contentPane.add(TornaIndietroLB);
		TornaIndietroLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				TornaIndietroLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/Indietrobtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				TornaIndietroLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/Indietrobtngreen.png")));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				
				indietro.setVisible(true);
				System.out.println("Ti trovi in "+indietro.getClass().getSimpleName());
				dispose();
				
			}
		});
		
		
		
		
		
		JLabel PaginaInizialeLB = new JLabel("");
		PaginaInizialeLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/paginainizialebtngreen.png")));
		PaginaInizialeLB.setBounds(127, 501, 168, 51);
		contentPane.add(PaginaInizialeLB);
		PaginaInizialeLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				paginainiziale.setVisible(true);
				System.out.println("Ti trovi nella pagina iniziale");
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				PaginaInizialeLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/paginizialebtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				PaginaInizialeLB.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/paginainizialebtngreen.png")));
			}
		});
		
	
		JLabel Sfondo = new JLabel("");
		Sfondo.setIcon(new ImageIcon(DettagliUtente.class.getResource("/Immagini/DettagliUtente/DettagliUtenteback.jpg")));
		Sfondo.setBounds(0, 0, 917, 563);
		contentPane.add(Sfondo);
		
	}
	
	private void InizializzaList(Controller controller, Utente utente) {
		
		ListaUtenti = controller.RicavaUtenti("select * from utente ;");
		int i;
		for(i=0; i<ListaUtenti.size(); i++){
			demoList.addElement(ListaUtenti.get(i).getNickName());
		}
		listaUtenti.setModel(demoList);
	}
}
