package Interfaccia;

import java.awt.Dimension;

import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Controller.Controller;
import ModelloUML.Album;
import ModelloUML.Artista_T;
import ModelloUML.Traccia;
import ModelloUML.Utente;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PannelloGenerale extends JFrame{

	private JFrame pannellogenerale;
	private JPanel contentPane;
	private JList<?> listaGenerale = new JList<>();
	private DefaultListModel demoList = new DefaultListModel();
	private ArrayList<Traccia> ListaTracce;
	private ArrayList<Album> ListaAlbum;
	private ArrayList<Artista_T> ListaArtisti;
	private JLabel PannelloGenerale = new JLabel("");
	private int l;
	private final JLabel Sfondo = new JLabel("");
	private final JLabel PaginaInizialeBTN = new JLabel("");
	private final JLabel DettTracciaLB = new JLabel("");
	private final JLabel DettArtLB = new JLabel("");
	private final JLabel DettAlLB = new JLabel("");
	
	public PannelloGenerale(JFrame paginainiziale, Controller controller, JFrame pagprecedente, Utente utente ,String cerca, int flag) {
		setResizable(false);

		paginainiziale.setVisible(false);
		pannellogenerale=this;
		pannellogenerale.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pannellogenerale = new JFrame();
		setBounds(100, 100, 933, 602);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Pannello generale");
		System.out.println("Ti trovi in pannello generale");
		
		Toolkit toolkit = getToolkit();
		Dimension size = toolkit.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
		
		InizializzaListaGenerale(controller,utente, flag, cerca);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(44, 121, 611, 354);
		contentPane.add(scrollPane);
		listaGenerale.setFont(new Font("Times New Roman", Font.BOLD, 24));
		scrollPane.setViewportView(listaGenerale);
		scrollPane.setBounds(44, 122, 609, 352);
		PannelloGenerale.setForeground(Color.WHITE);
		
		
		PannelloGenerale.setFont(new Font("Times New Roman", Font.BOLD, 27));
		PannelloGenerale.setHorizontalAlignment(SwingConstants.CENTER);
		PannelloGenerale.setBounds(204, 37, 479, 64);
		contentPane.add(PannelloGenerale);
		
		DettTracciaLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettaglitrbtngreen.png")));
		DettTracciaLB.setBounds(699, 243, 189, 75);
		contentPane.add(DettTracciaLB);
		DettTracciaLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				   if(listaGenerale.getSelectedIndex() != -1){
	                  
					    Traccia nome;
						nome = ListaTracce.get(listaGenerale.getSelectedIndex());
							
						DettagliTraccia dettaglitraccia = new DettagliTraccia(paginainiziale, controller, PannelloGenerale.this, utente, nome);
						dispose();
			
				   }
				   
	                else{
	                	
	                	JOptionPane.showMessageDialog(contentPane, "Non hai selezionato la traccia", "Attento!", JOptionPane.WARNING_MESSAGE);
				
	                }	
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				DettTracciaLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettaglitrbtnwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				DettTracciaLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettaglitrbtngreen.png")));
			}
		});
		
	
		DettAlLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettagliAlbbtngreen.png")));
		DettAlLB.setBounds(699, 243, 189, 75);
		contentPane.add(DettAlLB);
		DettAlLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				   if(listaGenerale.getSelectedIndex() != -1){
		                  
						Album nome;
						nome = ListaAlbum.get(listaGenerale.getSelectedIndex());
						DettagliAlbum dettaglialbum = new DettagliAlbum(paginainiziale, controller, PannelloGenerale.this, utente, nome);
						dispose();
			
				   }
				   
	                else{
	                	
	                	JOptionPane.showMessageDialog(contentPane, "Non hai selezionato l'album", "Attento!", JOptionPane.WARNING_MESSAGE);
				
	                }	
				
			
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				DettAlLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettagliAlbbtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				DettAlLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettagliAlbbtngreen.png")));
			}
		});
		
		
		DettArtLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettagliArbtngreen.png")));
		DettArtLB.setBounds(694, 243, 189, 75);
		contentPane.add(DettArtLB);
		DettArtLB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(listaGenerale.getSelectedIndex() != -1) {
					
				Artista_T nome;
				nome = ListaArtisti.get(listaGenerale.getSelectedIndex());
				DettagliArtista dettagliartista = new DettagliArtista(paginainiziale, controller, PannelloGenerale.this, utente, nome);
				dispose();
			
				}else {
					
					JOptionPane.showMessageDialog(contentPane, "Non hai selezionato l'artista", "Attento!", JOptionPane.WARNING_MESSAGE);
					
				}
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				DettArtLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettagliArbtnwhite.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				DettArtLB.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/dettagliArbtngreen.png")));
			}
		});
		
		PaginaInizialeBTN.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/paginainizialebtngreen.png")));
		PaginaInizialeBTN.setBounds(10, 502, 171, 50);
		contentPane.add(PaginaInizialeBTN);
		PaginaInizialeBTN.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				paginainiziale.setVisible(true);
				System.out.println("Ti trovi nella pagina iniziale");
				dispose();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				PaginaInizialeBTN.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/paginainizialebtnwhite.png")));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				PaginaInizialeBTN.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/paginainizialebtngreen.png")));
			}
		});
		
		
		
		Sfondo.setIcon(new ImageIcon(PannelloGenerale.class.getResource("/Immagini/PannelloGenerale/Sfondo.jpg")));
		Sfondo.setBounds(0, 0, 917, 563);
		
		contentPane.add(Sfondo);
		
		
		
	}
	
	private void InizializzaListaGenerale(Controller controller, Utente utente, int flag, String cerca) {
	
		if(cerca.equals("")) {
			cerca = "%";
		}
		
		switch(flag) {
		
		case 0:
			
			ListaAlbum = controller.RicavaAlbum("select * from album where nomealbum ilike '"+cerca+"%' order by nomealbum;");
			int i;
			for(i=0; i<ListaAlbum.size(); i++) {
				
				demoList.addElement(ListaAlbum.get(i).getNomeAlbum());
				
			}
			
			listaGenerale.setModel(demoList);
			
			DettTracciaLB.setVisible(false);
			DettArtLB.setVisible(false);
			if(cerca.equals("%")) {
				PannelloGenerale.setText("Risultato di tutti gli album");
			}else {
				PannelloGenerale.setText("Risultato album: "+cerca);
			}
			
			 listaGenerale.getSelectionModel().addListSelectionListener(e -> {
				   
				 l= listaGenerale.getSelectedIndex();
				 ListaAlbum.get(listaGenerale.getSelectedIndex());
		            
			 });

			break;
			
		case 1:
			
			ListaTracce = controller.RicavaTraccia("select * from traccia where nometraccia ilike '"+cerca+"%' order by nometraccia;");
			int j;
			for(j=0; j<ListaTracce.size(); j++) {
				
				demoList.addElement(ListaTracce.get(j).getNomeTraccia());
				
			}
			
			listaGenerale.setModel(demoList);
			DettAlLB.setVisible(false);
			DettArtLB.setVisible(false);
			if(cerca.equals("%")) {
				PannelloGenerale.setText("Risultato di tutte le tracce");
			}else {
				PannelloGenerale.setText("Risultato tracce: "+cerca);
			}
			
			 listaGenerale.getSelectionModel().addListSelectionListener(e -> {
				   
				 l = listaGenerale.getSelectedIndex();
				 ListaTracce.get(listaGenerale.getSelectedIndex());
				 	
		            
			 });
	
			break;
			
		case 2: 
			
			ListaArtisti = controller.RicavaArtisti("Select * from artista_t where nomeartista ilike '"+cerca+"%' order by nomeartista;");
			int x;
			for(x=0; x<ListaArtisti.size(); x++) {
				
				demoList.addElement(ListaArtisti.get(x).getNomeArtista());
				
			}
			
			listaGenerale.setModel(demoList);
			DettTracciaLB.setVisible(false);
			DettAlLB.setVisible(false);
			if(cerca.equals("%")) {
				PannelloGenerale.setText("Risultato di tutti gli artisti");
			}else {
				PannelloGenerale.setText("Risultato artisti: "+cerca);
			}
			
			 listaGenerale.getSelectionModel().addListSelectionListener(e -> {
				  
				 l = listaGenerale.getSelectedIndex();
				 ListaArtisti.get(listaGenerale.getSelectedIndex());
				 	
		            
			 });

			
		break;
		
		
		
		}
		

		
		
		
	}
}
