package Interfaccia;

import java.awt.Color;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalTime;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import Controller.Controller;
import ModelloUML.Utente;



public class Login extends JFrame{

	private JFrame login = new JFrame();
	private Controller controller;
	private Utente utente;
	private JLabel BenvenutoLB = new JLabel("");
	private JLabel NickNameLB = new JLabel("");
	private JLabel PasswordLB = new JLabel("");
	private JLabel TestoAccessoLB = new JLabel("");
	private JLabel TestoRegistrLB = new JLabel("");
	private JLabel Loginbtn = new JLabel("");
	private JLabel Registratibtn = new JLabel("");
	private JPasswordField passwordField = new JPasswordField();
	private JTextField NickNameField = new JTextField();
	/**
	 * Create the application.
	 */
	public Login(Controller controller) {
		
		System.out.println("Ti trovi in login");
		this.controller = controller;
		finestra();
		login.setVisible(true);
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void finestra() {
		
		
		login.setBounds(100, 100, 490, 630);
		login.setResizable(false);
		login.setTitle("LogIn Waihona Mele");
		login.setForeground(Color.DARK_GRAY);
		login.setFont(new Font("Dialog", Font.PLAIN, 26));
		login.getContentPane().setLayout(null);
		
		FinestraAlCentro();
	
		BenvenutoLB.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/Benvenuto.png")));
		BenvenutoLB.setForeground(new Color(255, 255, 255));
		BenvenutoLB.setFont(new Font("Times New Roman", Font.BOLD, 33));
		BenvenutoLB.setHorizontalAlignment(SwingConstants.CENTER);
		BenvenutoLB.setBounds(10, 25, 464, 46);
		login.getContentPane().add(BenvenutoLB);
		
		NickNameField.setForeground(new Color(0, 128, 0));
		NickNameField.setBounds(173, 194, 186, 23);
		login.getContentPane().add(NickNameField);
		NickNameField.setColumns(10);
		
		passwordField.setBounds(173, 258, 186, 23);
		login.getContentPane().add(passwordField);
		
		NickNameLB.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/NickName.png")));
		NickNameLB.setForeground(new Color(255, 255, 255));
		NickNameLB.setFont(new Font("Times New Roman", Font.BOLD, 16));
		NickNameLB.setBounds(71, 189, 102, 31);
		login.getContentPane().add(NickNameLB);
		
		
		PasswordLB.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/Password.png")));
		PasswordLB.setForeground(new Color(255, 255, 255));
		PasswordLB.setFont(new Font("Times New Roman", Font.BOLD, 16));
		PasswordLB.setBounds(79, 254, 102, 31);
		login.getContentPane().add(PasswordLB);
		
		TestoAccessoLB.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/UsaCredenziali.png")));
		TestoAccessoLB.setForeground(new Color(255, 255, 255));
		TestoAccessoLB.setHorizontalAlignment(SwingConstants.CENTER);
		TestoAccessoLB.setFont(new Font("Times New Roman", Font.BOLD, 17));
		TestoAccessoLB.setBounds(60, 121, 351, 31);
		login.getContentPane().add(TestoAccessoLB);
		
		TestoRegistrLB.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/CliccaSotto.png")));
		TestoRegistrLB.setForeground(new Color(255, 255, 255));
		TestoRegistrLB.setFont(new Font("Times New Roman", Font.BOLD, 15));
		TestoRegistrLB.setBounds(93, 397, 312, 23);
		login.getContentPane().add(TestoRegistrLB);
		
		Loginbtn.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/loginbtngreen.png")));
		Loginbtn.setBounds(176, 312, 127, 56);
		login.getContentPane().add(Loginbtn);
		LoginBTNListener(Loginbtn);
		
		Registratibtn.setBounds(151, 467, 179, 56);
		login.getContentPane().add(Registratibtn);
		Registratibtn.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/registratibtngreen.png")));
		RegistratiBTNListener(Registratibtn);
		
		JLabel SfondoLB = new JLabel("");
		SfondoLB.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/Background.jpg")));
		SfondoLB.setBounds(0, 0, 474, 591);
		login.getContentPane().add(SfondoLB);
	}
	
	//SETTA LA FINESTRA APERTA AL CENTRO DELLO SCHERMO
	private void FinestraAlCentro() {
		
		Toolkit toolkit = login.getToolkit();
		Dimension size = toolkit.getScreenSize();
		login.setLocation(size.width/2 - login.getWidth()/2, size.height/2 - login.getHeight()/2);
		
	}
	
	//SETTA IL CAMBIO DI SFONDO DEL BOTTONE REGISTRATI E CLICCANDO TI PORTA ALLA REGISTRAZIONE
	private void RegistratiBTNListener(JLabel Registratibtn) {

		
		Registratibtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
					
					Registratibtn.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/registratibtnwhite.png")));
					
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				Registratibtn.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/registratibtngreen.png")));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Registrazione reg = new Registrazione(controller, login);
				
			}
		});
		
	}
	
	
	//SETTA IL CAMBIO DI SFONDO DEL BOTTONE LOGIN E CLICCANDO TI FA ENTRARE NELLA LIBRERIA MUSICALE
	private void LoginBTNListener(JLabel Loginbtn) {
		
		Loginbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
					
					Loginbtn.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/loginbtnwhite.png")));
					
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				Loginbtn.setIcon(new ImageIcon(Login.class.getResource("/Immagini/Login/loginbtngreen.png")));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				
				utente = controller.AccessoUtente(NickNameField.getText(), passwordField.getText());
				
				if(utente == null) 
				{
					JOptionPane.showMessageDialog(login, "NickName o password errata");
				}
				else 
				{
					PaginaIniziale pgin = new PaginaIniziale(login, utente, controller);
					passwordField.setText("");
					NickNameField.setText("");
					System.out.println("Benvenuto " + utente.getNickName()+ "!");
			
				}
				
			}
		});
		
	}


}
